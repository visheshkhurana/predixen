import React, { useState, useCallback, useEffect } from 'react';
import Head from 'next/head';

// ============================================================================
// TYPES & INTERFACES
// ============================================================================

interface BenchmarkCount {
  industry: string;
  count: number;
}

interface PatternCount {
  type: string;
  count: number;
}

interface CurrentCounts {
  benchmarks: BenchmarkCount[];
  patterns: PatternCount[];
}

interface ImportResult {
  success: boolean;
  message: string;
  inserted?: {
    benchmarks: number;
    patterns: number;
  };
  updated?: {
    benchmarks: number;
    patterns: number;
  };
  errors?: string[];
}

interface TabProps {
  isActive: boolean;
  onClick: () => void;
  children: React.ReactNode;
}

// ============================================================================
// MOCK DATA & CONSTANTS
// ============================================================================

const TABS = [
  'System Status',
  'Database',
  'Cache',
  'Logs',
  'Backups',
  'Settings',
  'Research Data',
] as const;

type TabType = (typeof TABS)[number];

const EXAMPLE_RESEARCH_DATA = {
  benchmarks: [
    {
      industry: 'Technology',
      metric: 'Average Response Time',
      value: 150,
      unit: 'ms',
      source: 'Industry Report 2024',
      year: 2024,
    },
  ],
  patterns: [
    {
      type: 'Performance',
      name: 'Caching Strategy',
      description: 'Implement multi-layer caching',
      examples: ['Redis', 'CDN'],
    },
  ],
};

const TEMPLATE_DATA = {
  benchmarks: [
    {
      industry: 'string (required)',
      metric: 'string (required)',
      value: 'number (required)',
      unit: 'string (optional)',
      source: 'string (optional)',
      year: 'number (optional)',
    },
  ],
  patterns: [
    {
      type: 'string (required)',
      name: 'string (required)',
      description: 'string (required)',
      examples: ['array of strings (optional)'],
    },
  ],
};

// ============================================================================
// STYLES
// ============================================================================

const styles: Record<string, React.CSSProperties> = {
  container: {
    padding: '24px',
    maxWidth: '1400px',
    margin: '0 auto',
    fontFamily: 'system-ui, -apple-system, sans-serif',
  },
  header: {
    marginBottom: '24px',
  },
  title: {
    fontSize: '28px',
    fontWeight: '600',
    color: '#1a1a1a',
    margin: '0 0 8px 0',
  },
  subtitle: {
    fontSize: '14px',
    color: '#666',
    margin: 0,
  },
  tabsContainer: {
    display: 'flex',
    borderBottom: '1px solid #e0e0e0',
    marginBottom: '24px',
    gap: '4px',
  },
  tab: {
    padding: '12px 20px',
    fontSize: '14px',
    fontWeight: '500',
    color: '#666',
    background: 'transparent',
    border: 'none',
    borderBottom: '2px solid transparent',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  },
  tabActive: {
    color: '#2563eb',
    borderBottomColor: '#2563eb',
  },
  content: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    padding: '24px',
    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
  },
  // Research Data Tab Styles
  section: {
    marginBottom: '32px',
  },
  sectionTitle: {
    fontSize: '18px',
    fontWeight: '600',
    color: '#1a1a1a',
    margin: '0 0 16px 0',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  sectionIcon: {
    fontSize: '20px',
  },
  countsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
    gap: '20px',
    marginBottom: '24px',
  },
  countCard: {
    backgroundColor: '#f8fafc',
    borderRadius: '8px',
    padding: '20px',
    border: '1px solid #e2e8f0',
  },
  countCardHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '16px',
  },
  countCardTitle: {
    fontSize: '14px',
    fontWeight: '600',
    color: '#475569',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
  },
  countCardTotal: {
    fontSize: '24px',
    fontWeight: '700',
    color: '#2563eb',
  },
  countList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px',
  },
  countItem: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '8px 12px',
    backgroundColor: '#fff',
    borderRadius: '6px',
    fontSize: '14px',
  },
  countItemLabel: {
    color: '#64748b',
  },
  countItemValue: {
    fontWeight: '600',
    color: '#1e293b',
  },
  // Upload Area Styles
  uploadArea: {
    border: '2px dashed #cbd5e1',
    borderRadius: '12px',
    padding: '32px',
    textAlign: 'center',
    backgroundColor: '#f8fafc',
    transition: 'all 0.2s ease',
    cursor: 'pointer',
  },
  uploadAreaActive: {
    borderColor: '#2563eb',
    backgroundColor: '#eff6ff',
  },
  uploadIcon: {
    fontSize: '48px',
    marginBottom: '16px',
  },
  uploadText: {
    fontSize: '16px',
    color: '#475569',
    marginBottom: '8px',
  },
  uploadSubtext: {
    fontSize: '14px',
    color: '#94a3b8',
  },
  fileInput: {
    display: 'none',
  },
  textArea: {
    width: '100%',
    minHeight: '200px',
    padding: '16px',
    fontSize: '14px',
    fontFamily: 'monospace',
    border: '1px solid #e2e8f0',
    borderRadius: '8px',
    resize: 'vertical',
    backgroundColor: '#fff',
  },
  // Format Reference Styles
  formatSection: {
    backgroundColor: '#f8fafc',
    borderRadius: '8px',
    padding: '20px',
    marginTop: '20px',
  },
  formatHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '16px',
  },
  formatTitle: {
    fontSize: '14px',
    fontWeight: '600',
    color: '#475569',
  },
  codeBlock: {
    backgroundColor: '#1e293b',
    color: '#e2e8f0',
    padding: '16px',
    borderRadius: '8px',
    fontSize: '13px',
    fontFamily: 'monospace',
    overflow: 'auto',
    maxHeight: '300px',
    whiteSpace: 'pre-wrap',
    wordBreak: 'break-word',
  },
  // Button Styles
  button: {
    padding: '10px 20px',
    fontSize: '14px',
    fontWeight: '500',
    borderRadius: '6px',
    border: 'none',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    display: 'inline-flex',
    alignItems: 'center',
    gap: '8px',
  },
  buttonPrimary: {
    backgroundColor: '#2563eb',
    color: '#fff',
  },
  buttonSecondary: {
    backgroundColor: '#e2e8f0',
    color: '#475569',
  },
  buttonSuccess: {
    backgroundColor: '#10b981',
    color: '#fff',
  },
  buttonDanger: {
    backgroundColor: '#ef4444',
    color: '#fff',
  },
  buttonDisabled: {
    opacity: 0.5,
    cursor: 'not-allowed',
  },
  buttonGroup: {
    display: 'flex',
    gap: '12px',
    marginTop: '20px',
  },
  // Alert/Feedback Styles
  alert: {
    padding: '16px',
    borderRadius: '8px',
    marginBottom: '20px',
    display: 'flex',
    alignItems: 'flex-start',
    gap: '12px',
  },
  alertSuccess: {
    backgroundColor: '#dcfce7',
    border: '1px solid #86efac',
    color: '#166534',
  },
  alertError: {
    backgroundColor: '#fee2e2',
    border: '1px solid #fca5a5',
    color: '#991b1b',
  },
  alertInfo: {
    backgroundColor: '#dbeafe',
    border: '1px solid #93c5fd',
    color: '#1e40af',
  },
  alertIcon: {
    fontSize: '20px',
    flexShrink: 0,
  },
  alertContent: {
    flex: 1,
  },
  alertTitle: {
    fontWeight: '600',
    marginBottom: '4px',
  },
  alertMessage: {
    fontSize: '14px',
  },
  // Results Styles
  resultsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, 1fr)',
    gap: '16px',
    marginTop: '16px',
  },
  resultCard: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    padding: '16px',
    border: '1px solid #e2e8f0',
  },
  resultLabel: {
    fontSize: '12px',
    color: '#64748b',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
    marginBottom: '8px',
  },
  resultValue: {
    fontSize: '24px',
    fontWeight: '700',
    color: '#1e293b',
  },
  // Loading Styles
  spinner: {
    width: '16px',
    height: '16px',
    border: '2px solid transparent',
    borderTopColor: 'currentColor',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite',
  },
  // Tab Content Placeholder
  placeholderContent: {
    textAlign: 'center',
    padding: '60px 20px',
    color: '#94a3b8',
  },
  placeholderIcon: {
    fontSize: '64px',
    marginBottom: '16px',
  },
  placeholderTitle: {
    fontSize: '20px',
    fontWeight: '600',
    color: '#64748b',
    marginBottom: '8px',
  },
  placeholderText: {
    fontSize: '14px',
  },
};

// ============================================================================
// HELPER COMPONENTS
// ============================================================================

const Tab: React.FC<TabProps> = ({ isActive, onClick, children }) => (
  <button
    onClick={onClick}
    style={{
      ...styles.tab,
      ...(isActive ? styles.tabActive : {}),
    }}
  >
    {children}
  </button>
);

const Alert: React.FC<{
  type: 'success' | 'error' | 'info';
  title?: string;
  message: string;
  children?: React.ReactNode;
}> = ({ type, title, message, children }) => {
  const alertStyles = {
    success: styles.alertSuccess,
    error: styles.alertError,
    info: styles.alertInfo,
  };

  const icons = {
    success: '✓',
    error: '✕',
    info: 'ℹ',
  };

  return (
    <div style={{ ...styles.alert, ...alertStyles[type] }}>
      <span style={styles.alertIcon}>{icons[type]}</span>
      <div style={styles.alertContent}>
        {title && <div style={styles.alertTitle}>{title}</div>}
        <div style={styles.alertMessage}>{message}</div>
        {children}
      </div>
    </div>
  );
};

// ============================================================================
// RESEARCH DATA TAB COMPONENT
// ============================================================================

const ResearchDataTab: React.FC = () => {
  const [jsonInput, setJsonInput] = useState<string>('');
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [counts, setCounts] = useState<CurrentCounts | null>(null);
  const [countsLoading, setCountsLoading] = useState<boolean>(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  // Fetch current counts on mount
  useEffect(() => {
    fetchCounts();
  }, []);

  const fetchCounts = async () => {
    setCountsLoading(true);
    try {
      // Mock API call - replace with actual endpoint
      // const response = await fetch('/api/system/research-data-counts');
      // const data = await response.json();
      
      // Simulated response
      await new Promise(resolve => setTimeout(resolve, 500));
      const mockCounts: CurrentCounts = {
        benchmarks: [
          { industry: 'Technology', count: 45 },
          { industry: 'Healthcare', count: 32 },
          { industry: 'Finance', count: 28 },
          { industry: 'Manufacturing', count: 21 },
          { industry: 'Retail', count: 18 },
          { industry: 'Energy', count: 15 },
        ],
        patterns: [
          { type: 'Architecture', count: 38 },
          { type: 'Performance', count: 29 },
          { type: 'Security', count: 24 },
          { type: 'Scalability', count: 22 },
          { type: 'Reliability', count: 19 },
          { type: 'Cost Optimization', count: 16 },
        ],
      };
      setCounts(mockCounts);
    } catch (error) {
      console.error('Failed to fetch counts:', error);
    } finally {
      setCountsLoading(false);
    }
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFile(files[0]);
    }
  }, []);

  const handleFile = (file: File) => {
    if (file.type !== 'application/json' && !file.name.endsWith('.json')) {
      setResult({
        success: false,
        message: 'Please upload a valid JSON file.',
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      setJsonInput(content);
      setResult(null);
    };
    reader.onerror = () => {
      setResult({
        success: false,
        message: 'Failed to read the file. Please try again.',
      });
    };
    reader.readAsText(file);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFile(file);
    }
  };

  const handleDownloadTemplate = () => {
    const blob = new Blob([JSON.stringify(TEMPLATE_DATA, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'research-data-template.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImport = async () => {
    if (!jsonInput.trim()) {
      setResult({
        success: false,
        message: 'Please paste JSON data or upload a file first.',
      });
      return;
    }

    // Validate JSON
    let parsedData;
    try {
      parsedData = JSON.parse(jsonInput);
    } catch (error) {
      setResult({
        success: false,
        message: 'Invalid JSON format. Please check your input.',
      });
      return;
    }

    setIsLoading(true);
    setResult(null);

    try {
      // Mock API call - replace with actual endpoint
      // const response = await fetch('/api/system/import-research-data', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(parsedData),
      // });
      // const data = await response.json();

      // Simulated response
      await new Promise(resolve => setTimeout(resolve, 1500));
      const mockResult: ImportResult = {
        success: true,
        message: 'Research data imported successfully!',
        inserted: {
          benchmarks: parsedData.benchmarks?.length || 0,
          patterns: parsedData.patterns?.length || 0,
        },
        updated: {
          benchmarks: Math.floor(Math.random() * 5),
          patterns: Math.floor(Math.random() * 3),
        },
      };
      setResult(mockResult);
      
      // Refresh counts after successful import
      fetchCounts();
    } catch (error) {
      setResult({
        success: false,
        message: 'Failed to import research data. Please try again.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    setJsonInput('');
    setResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const totalBenchmarks = counts?.benchmarks.reduce((sum, b) => sum + b.count, 0) || 0;
  const totalPatterns = counts?.patterns.reduce((sum, p) => sum + p.count, 0) || 0;

  return (
    <div>
      {/* Current Counts Display */}
      <div style={styles.section}>
        <h3 style={styles.sectionTitle}>
          <span style={styles.sectionIcon}>📊</span>
          Current Data Counts
        </h3>
        
        {countsLoading ? (
          <div style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>
            Loading counts...
          </div>
        ) : counts ? (
          <div style={styles.countsGrid}>
            {/* Benchmarks Card */}
            <div style={styles.countCard}>
              <div style={styles.countCardHeader}>
                <span style={styles.countCardTitle}>Benchmarks by Industry</span>
                <span style={styles.countCardTotal}>{totalBenchmarks}</span>
              </div>
              <div style={styles.countList}>
                {counts.benchmarks.map((item) => (
                  <div key={item.industry} style={styles.countItem}>
                    <span style={styles.countItemLabel}>{item.industry}</span>
                    <span style={styles.countItemValue}>{item.count}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Patterns Card */}
            <div style={styles.countCard}>
              <div style={styles.countCardHeader}>
                <span style={styles.countCardTitle}>Patterns by Type</span>
                <span style={styles.countCardTotal}>{totalPatterns}</span>
              </div>
              <div style={styles.countList}>
                {counts.patterns.map((item) => (
                  <div key={item.type} style={styles.countItem}>
                    <span style={styles.countItemLabel}>{item.type}</span>
                    <span style={styles.countItemValue}>{item.count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <Alert type="error" message="Failed to load current counts." />
        )}
      </div>

      {/* Upload Area */}
      <div style={styles.section}>
        <h3 style={styles.sectionTitle}>
          <span style={styles.sectionIcon}>📤</span>
          Import Research Data
        </h3>

        {/* Drag & Drop Area */}
        <div
          style={{
            ...styles.uploadArea,
            ...(isDragging ? styles.uploadAreaActive : {}),
          }}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <div style={styles.uploadIcon}>📁</div>
          <div style={styles.uploadText}>
            Drag & drop a JSON file here, or click to browse
          </div>
          <div style={styles.uploadSubtext}>
            Supports .json files up to 10MB
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json,application/json"
            onChange={handleFileInputChange}
            style={styles.fileInput}
          />
        </div>

        {/* JSON Text Area */}
        <div style={{ marginTop: '20px' }}>
          <label
            style={{
              display: 'block',
              fontSize: '14px',
              fontWeight: '500',
              color: '#475569',
              marginBottom: '8px',
            }}
          >
            Or paste JSON directly:
          </label>
          <textarea
            value={jsonInput}
            onChange={(e) => {
              setJsonInput(e.target.value);
              setResult(null);
            }}
            placeholder="Paste your research data JSON here..."
            style={styles.textArea}
          />
        </div>

        {/* Action Buttons */}
        <div style={styles.buttonGroup}>
          <button
            onClick={handleImport}
            disabled={isLoading || !jsonInput.trim()}
            style={{
              ...styles.button,
              ...styles.buttonPrimary,
              ...(isLoading || !jsonInput.trim() ? styles.buttonDisabled : {}),
            }}
          >
            {isLoading ? (
              <>
                <span style={styles.spinner} />
                Importing...
              </>
            ) : (
              <>
                <span>🚀</span>
                Import Data
              </>
            )}
          </button>
          <button
            onClick={handleClear}
            disabled={isLoading}
            style={{
              ...styles.button,
              ...styles.buttonSecondary,
              ...(isLoading ? styles.buttonDisabled : {}),
            }}
          >
            <span>🗑️</span>
            Clear
          </button>
        </div>

        {/* Result Feedback */}
        {result && (
          <div style={{ marginTop: '20px' }}>
            {result.success ? (
              <Alert
                type="success"
                title="Import Successful!"
                message={result.message}
              >
                {(result.inserted || result.updated) && (
                  <div style={styles.resultsGrid}>
                    {result.inserted && (
                      <>
                        <div style={styles.resultCard}>
                          <div style={styles.resultLabel}>Benchmarks Inserted</div>
                          <div style={styles.resultValue}>{result.inserted.benchmarks}</div>
                        </div>
                        <div style={styles.resultCard}>
                          <div style={styles.resultLabel}>Patterns Inserted</div>
                          <div style={styles.resultValue}>{result.inserted.patterns}</div>
                        </div>
                      </>
                    )}
                    {result.updated && (
                      <>
                        <div style={styles.resultCard}>
                          <div style={styles.resultLabel}>Benchmarks Updated</div>
                          <div style={styles.resultValue}>{result.updated.benchmarks}</div>
                        </div>
                        <div style={styles.resultCard}>
                          <div style={styles.resultLabel}>Patterns Updated</div>
                          <div style={styles.resultValue}>{result.updated.patterns}</div>
                        </div>
                      </>
                    )}
                  </div>
                )}
              </Alert>
            ) : (
              <Alert type="error" title="Import Failed" message={result.message} />
            )}
          </div>
        )}
      </div>

      {/* Format Reference */}
      <div style={styles.section}>
        <h3 style={styles.sectionTitle}>
          <span style={styles.sectionIcon}>📋</span>
          Format Reference
        </h3>

        <div style={styles.formatSection}>
          <div style={styles.formatHeader}>
            <span style={styles.formatTitle}>Expected JSON Format</span>
            <button
              onClick={handleDownloadTemplate}
              style={{ ...styles.button, ...styles.buttonSecondary }}
            >
              <span>⬇️</span>
              Download Template
            </button>
          </div>
          <pre style={styles.codeBlock}>
            {JSON.stringify(EXAMPLE_RESEARCH_DATA, null, 2)}
          </pre>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// PLACEHOLDER TAB COMPONENTS
// ============================================================================

const PlaceholderTab: React.FC<{ title: string; icon: string }> = ({
  title,
  icon,
}) => (
  <div style={styles.placeholderContent}>
    <div style={styles.placeholderIcon}>{icon}</div>
    <h3 style={styles.placeholderTitle}>{title}</h3>
    <p style={styles.placeholderText}>
      This section is under development. Check back soon for updates.
    </p>
  </div>
);

// ============================================================================
// MAIN SYSTEM TOOLS PAGE
// ============================================================================

const SystemToolsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('Research Data');

  const renderTabContent = () => {
    switch (activeTab) {
      case 'System Status':
        return <PlaceholderTab title="System Status" icon="🖥️" />;
      case 'Database':
        return <PlaceholderTab title="Database Management" icon="🗄️" />;
      case 'Cache':
        return <PlaceholderTab title="Cache Management" icon="⚡" />;
      case 'Logs':
        return <PlaceholderTab title="System Logs" icon="📜" />;
      case 'Backups':
        return <PlaceholderTab title="Backup & Restore" icon="💾" />;
      case 'Settings':
        return <PlaceholderTab title="System Settings" icon="⚙️" />;
      case 'Research Data':
        return <ResearchDataTab />;
      default:
        return null;
    }
  };

  return (
    <>
      <Head>
        <title>System Tools | Admin</title>
      </Head>
      
      {/* Add keyframe animation for spinner */}
      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>

      <div style={styles.container}>
        <header style={styles.header}>
          <h1 style={styles.title}>System Tools</h1>
          <p style={styles.subtitle}>
            Manage system settings, monitor performance, and import research data
          </p>
        </header>

        <nav style={styles.tabsContainer}>
          {TABS.map((tab) => (
            <Tab
              key={tab}
              isActive={activeTab === tab}
              onClick={() => setActiveTab(tab)}
            >
              {tab}
            </Tab>
          ))}
        </nav>

        <main style={styles.content}>{renderTabContent()}</main>
      </div>
    </>
  );
};

export default SystemToolsPage;
