"""
Market Intelligence Agent with Comprehensive Industry Benchmarks

This module provides market analysis capabilities with industry-specific benchmarks
for startup evaluation, competitive positioning, and market sizing.

Industries Covered:
- SaaS (Software as a Service)
- Fintech (Financial Technology)
- Marketplace (Two-sided platforms)
- D2C (Direct-to-Consumer)
- Healthtech (Healthcare Technology)
- Consumer Subscriptions
- Hardware
- Services
"""

from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
import json


class CompanyStage(Enum):
    """Startup lifecycle stages for benchmark context."""
    SEED = "seed"
    SERIES_A = "series_a"
    SERIES_B = "series_b"
    SERIES_C = "series_c"
    GROWTH = "growth"
    LATE_STAGE = "late_stage"


class MarketPosition(Enum):
    """Competitive market positioning categories."""
    LEADER = "leader"
    CHALLENGER = "challenger"
    FOLLOWER = "follower"
    NICHE = "niche"
    EMERGING = "emerging"


@dataclass
class MarketMetrics:
    """Standardized market metrics container."""
    # Market Sizing
    tam: Optional[float] = None  # Total Addressable Market ($B)
    sam: Optional[float] = None  # Serviceable Addressable Market ($B)
    som: Optional[float] = None  # Serviceable Obtainable Market ($B)
    
    # Growth Metrics
    revenue_growth_mom: Optional[float] = None  # Month-over-month growth %
    revenue_growth_yoy: Optional[float] = None  # Year-over-year growth %
    growth_rate: Optional[float] = None  # Annual growth rate %
    
    # Unit Economics
    ltv: Optional[float] = None  # Lifetime Value ($)
    cac: Optional[float] = None  # Customer Acquisition Cost ($)
    ltv_cac_ratio: Optional[float] = None
    payback_period_months: Optional[float] = None
    
    # Retention Metrics
    churn_rate_monthly: Optional[float] = None  # Monthly churn %
    churn_rate_annual: Optional[float] = None  # Annual churn %
    net_revenue_retention: Optional[float] = None  # NRR %
    gross_revenue_retention: Optional[float] = None  # GRR %
    
    # Efficiency Metrics
    burn_multiple: Optional[float] = None
    runway_months: Optional[float] = None
    rule_of_40: Optional[float] = None  # Growth rate + Profit margin
    magic_number: Optional[float] = None  # Sales efficiency
    
    # Margin Metrics
    gross_margin: Optional[float] = None  # %
    net_margin: Optional[float] = None  # %
    ebitda_margin: Optional[float] = None  # %
    operating_margin: Optional[float] = None  # %
    
    # Industry-Specific
    arpu: Optional[float] = None  # Average Revenue Per User ($)
    arpu_monthly: Optional[float] = None
    mau: Optional[int] = None  # Monthly Active Users
    dau: Optional[int] = None  # Daily Active Users
    conversion_rate: Optional[float] = None  # %
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert metrics to dictionary."""
        return {
            k: v for k, v in self.__dict__.items() 
            if v is not None
        }


# =============================================================================
# COMPREHENSIVE INDUSTRY BENCHMARKS
# =============================================================================

INDUSTRY_BENCHMARKS = {
    # =========================================================================
    # SaaS (Software as a Service)
    # =========================================================================
    "saas": {
        "display_name": "SaaS (Software as a Service)",
        "description": "Cloud-based software solutions with subscription revenue models",
        "stages": {
            CompanyStage.SEED: {
                "metrics": MarketMetrics(
                    tam=10.0,  # $10B market
                    revenue_growth_mom=15.0,
                    growth_rate=200.0,
                    ltv=5000.0,
                    cac=1000.0,
                    ltv_cac_ratio=5.0,
                    payback_period_months=12.0,
                    churn_rate_monthly=5.0,
                    churn_rate_annual=40.0,
                    net_revenue_retention=100.0,
                    gross_revenue_retention=85.0,
                    gross_margin=70.0,
                    net_margin=-50.0,
                    burn_multiple=2.0,
                    runway_months=18.0,
                    arpu_monthly=100.0,
                    conversion_rate=2.0,
                ),
                "valuation_multiple": "8-12x ARR",
                "typical_arr_range": "$0-1M"
            },
            CompanyStage.SERIES_A: {
                "metrics": MarketMetrics(
                    tam=25.0,
                    revenue_growth_mom=12.0,
                    growth_rate=150.0,
                    ltv=8000.0,
                    cac=1500.0,
                    ltv_cac_ratio=5.5,
                    payback_period_months=14.0,
                    churn_rate_monthly=4.0,
                    churn_rate_annual=35.0,
                    net_revenue_retention=105.0,
                    gross_revenue_retention=88.0,
                    gross_margin=75.0,
                    net_margin=-30.0,
                    burn_multiple=1.5,
                    runway_months=24.0,
                    rule_of_40=120.0,
                    magic_number=0.7,
                    arpu_monthly=150.0,
                    conversion_rate=3.0,
                ),
                "valuation_multiple": "10-15x ARR",
                "typical_arr_range": "$1M-5M"
            },
            CompanyStage.SERIES_B: {
                "metrics": MarketMetrics(
                    tam=50.0,
                    revenue_growth_mom=10.0,
                    growth_rate=100.0,
                    ltv=12000.0,
                    cac=2000.0,
                    ltv_cac_ratio=6.0,
                    payback_period_months=16.0,
                    churn_rate_monthly=3.0,
                    churn_rate_annual=30.0,
                    net_revenue_retention=110.0,
                    gross_revenue_retention=90.0,
                    gross_margin=78.0,
                    net_margin=-15.0,
                    burn_multiple=1.2,
                    runway_months=30.0,
                    rule_of_40=85.0,
                    magic_number=0.8,
                    arpu_monthly=200.0,
                    conversion_rate=4.0,
                ),
                "valuation_multiple": "12-18x ARR",
                "typical_arr_range": "$5M-20M"
            },
            CompanyStage.SERIES_C: {
                "metrics": MarketMetrics(
                    tam=100.0,
                    revenue_growth_mom=8.0,
                    growth_rate=70.0,
                    ltv=15000.0,
                    cac=2500.0,
                    ltv_cac_ratio=6.0,
                    payback_period_months=18.0,
                    churn_rate_monthly=2.5,
                    churn_rate_annual=25.0,
                    net_revenue_retention=115.0,
                    gross_revenue_retention=92.0,
                    gross_margin=80.0,
                    net_margin=-5.0,
                    burn_multiple=1.0,
                    runway_months=36.0,
                    rule_of_40=65.0,
                    magic_number=0.9,
                    arpu_monthly=250.0,
                    conversion_rate=5.0,
                ),
                "valuation_multiple": "15-25x ARR",
                "typical_arr_range": "$20M-100M"
            },
            CompanyStage.GROWTH: {
                "metrics": MarketMetrics(
                    tam=200.0,
                    revenue_growth_mom=5.0,
                    growth_rate=50.0,
                    ltv=20000.0,
                    cac=3000.0,
                    ltv_cac_ratio=6.5,
                    payback_period_months=18.0,
                    churn_rate_monthly=2.0,
                    churn_rate_annual=20.0,
                    net_revenue_retention=120.0,
                    gross_revenue_retention=93.0,
                    gross_margin=82.0,
                    net_margin=10.0,
                    burn_multiple=0.8,
                    runway_months=48.0,
                    rule_of_40=60.0,
                    magic_number=1.0,
                    arpu_monthly=300.0,
                    conversion_rate=6.0,
                ),
                "valuation_multiple": "20-30x ARR",
                "typical_arr_range": "$100M-500M"
            },
            CompanyStage.LATE_STAGE: {
                "metrics": MarketMetrics(
                    tam=500.0,
                    revenue_growth_mom=3.0,
                    growth_rate=30.0,
                    ltv=25000.0,
                    cac=3500.0,
                    ltv_cac_ratio=7.0,
                    payback_period_months=18.0,
                    churn_rate_monthly=1.5,
                    churn_rate_annual=15.0,
                    net_revenue_retention=125.0,
                    gross_revenue_retention=95.0,
                    gross_margin=85.0,
                    net_margin=20.0,
                    ebitda_margin=15.0,
                    operating_margin=18.0,
                    burn_multiple=0.5,
                    runway_months=60.0,
                    rule_of_40=50.0,
                    magic_number=1.2,
                    arpu_monthly=400.0,
                    conversion_rate=8.0,
                ),
                "valuation_multiple": "25-40x ARR",
                "typical_arr_range": "$500M+"
            }
        },
        "industry_specific_metrics": {
            "net_dollar_retention_top_quartile": 120.0,
            "net_dollar_retention_median": 105.0,
            "gross_dollar_retention_top_quartile": 95.0,
            "gross_dollar_retention_median": 88.0,
            "typical_contract_value_acv": 25000.0,
            "sales_cycle_months": 3.0,
            "expansion_revenue_rate": 20.0,
        },
        "key_characteristics": [
            "Recurring revenue model with predictable cash flows",
            "High gross margins (70-85%)",
            "Strong customer retention critical for success",
            "Land-and-expand growth strategy",
            "Product-led growth becoming dominant"
        ]
    },
    
    # =========================================================================
    # FINTECH (Financial Technology)
    # =========================================================================
    "fintech": {
        "display_name": "Fintech (Financial Technology)",
        "description": "Technology-enabled financial services and products",
        "stages": {
            CompanyStage.SEED: {
                "metrics": MarketMetrics(
                    tam=50.0,
                    revenue_growth_mom=20.0,
                    growth_rate=250.0,
                    ltv=3000.0,
                    cac=800.0,
                    ltv_cac_ratio=3.8,
                    payback_period_months=10.0,
                    churn_rate_monthly=6.0,
                    churn_rate_annual=45.0,
                    net_revenue_retention=95.0,
                    gross_revenue_retention=80.0,
                    gross_margin=55.0,
                    net_margin=-60.0,
                    burn_multiple=2.5,
                    runway_months=15.0,
                    arpu_monthly=50.0,
                    conversion_rate=3.0,
                ),
                "valuation_multiple": "5-10x Revenue",
                "typical_arr_range": "$0-2M"
            },
            CompanyStage.SERIES_A: {
                "metrics": MarketMetrics(
                    tam=100.0,
                    revenue_growth_mom=15.0,
                    growth_rate=180.0,
                    ltv=5000.0,
                    cac=1200.0,
                    ltv_cac_ratio=4.2,
                    payback_period_months=12.0,
                    churn_rate_monthly=5.0,
                    churn_rate_annual=40.0,
                    net_revenue_retention=100.0,
                    gross_revenue_retention=83.0,
                    gross_margin=60.0,
                    net_margin=-40.0,
                    burn_multiple=2.0,
                    runway_months=20.0,
                    arpu_monthly=75.0,
                    conversion_rate=4.0,
                ),
                "valuation_multiple": "8-15x Revenue",
                "typical_arr_range": "$2M-10M"
            },
            CompanyStage.SERIES_B: {
                "metrics": MarketMetrics(
                    tam=200.0,
                    revenue_growth_mom=12.0,
                    growth_rate=120.0,
                    ltv=8000.0,
                    cac=1800.0,
                    ltv_cac_ratio=4.5,
                    payback_period_months=14.0,
                    churn_rate_monthly=4.0,
                    churn_rate_annual=35.0,
                    net_revenue_retention=105.0,
                    gross_revenue_retention=86.0,
                    gross_margin=65.0,
                    net_margin=-20.0,
                    burn_multiple=1.5,
                    runway_months=24.0,
                    rule_of_40=100.0,
                    arpu_monthly=100.0,
                    conversion_rate=5.0,
                ),
                "valuation_multiple": "10-20x Revenue",
                "typical_arr_range": "$10M-50M"
            },
            CompanyStage.SERIES_C: {
                "metrics": MarketMetrics(
                    tam=400.0,
                    revenue_growth_mom=10.0,
                    growth_rate=80.0,
                    ltv=12000.0,
                    cac=2500.0,
                    ltv_cac_ratio=4.8,
                    payback_period_months=16.0,
                    churn_rate_monthly=3.0,
                    churn_rate_annual=30.0,
                    net_revenue_retention=110.0,
                    gross_revenue_retention=88.0,
                    gross_margin=70.0,
                    net_margin=-5.0,
                    burn_multiple=1.2,
                    runway_months=30.0,
                    rule_of_40=75.0,
                    arpu_monthly=150.0,
                    conversion_rate=6.0,
                ),
                "valuation_multiple": "15-25x Revenue",
                "typical_arr_range": "$50M-200M"
            },
            CompanyStage.GROWTH: {
                "metrics": MarketMetrics(
                    tam=800.0,
                    revenue_growth_mom=7.0,
                    growth_rate=50.0,
                    ltv=15000.0,
                    cac=3000.0,
                    ltv_cac_ratio=5.0,
                    payback_period_months=16.0,
                    churn_rate_monthly=2.5,
                    churn_rate_annual=25.0,
                    net_revenue_retention=115.0,
                    gross_revenue_retention=90.0,
                    gross_margin=72.0,
                    net_margin=10.0,
                    burn_multiple=1.0,
                    runway_months=36.0,
                    rule_of_40=60.0,
                    arpu_monthly=200.0,
                    conversion_rate=7.0,
                ),
                "valuation_multiple": "20-35x Revenue",
                "typical_arr_range": "$200M-1B"
            },
            CompanyStage.LATE_STAGE: {
                "metrics": MarketMetrics(
                    tam=1500.0,
                    revenue_growth_mom=5.0,
                    growth_rate=30.0,
                    ltv=20000.0,
                    cac=3500.0,
                    ltv_cac_ratio=5.5,
                    payback_period_months=16.0,
                    churn_rate_monthly=2.0,
                    churn_rate_annual=20.0,
                    net_revenue_retention=120.0,
                    gross_revenue_retention=92.0,
                    gross_margin=75.0,
                    net_margin=18.0,
                    ebitda_margin=12.0,
                    burn_multiple=0.8,
                    runway_months=48.0,
                    rule_of_40=48.0,
                    arpu_monthly=250.0,
                    conversion_rate=8.0,
                ),
                "valuation_multiple": "25-45x Revenue",
                "typical_arr_range": "$1B+"
            }
        },
        "industry_specific_metrics": {
            "transaction_take_rate": 2.5,  # %
            "fraud_rate": 0.5,  # %
            "customer_acquisition_cost_banking": 300.0,
            "customer_acquisition_cost_lending": 800.0,
            "customer_acquisition_cost_payments": 150.0,
            "regulatory_compliance_cost_pct": 8.0,
            "average_transaction_value": 75.0,
            "transactions_per_user_monthly": 12.0,
        },
        "key_characteristics": [
            "Highly regulated industry requiring compliance expertise",
            "Lower gross margins due to financial intermediary costs",
            "Trust and security are critical differentiators",
            "Network effects can create strong moats",
            "Customer acquisition often through partnerships"
        ]
    },
    
    # =========================================================================
    # MARKETPLACE (Two-sided Platforms)
    # =========================================================================
    "marketplace": {
        "display_name": "Marketplace (Two-sided Platforms)",
        "description": "Platforms connecting buyers and sellers, taking transaction fees",
        "stages": {
            CompanyStage.SEED: {
                "metrics": MarketMetrics(
                    tam=20.0,
                    revenue_growth_mom=25.0,
                    growth_rate=300.0,
                    ltv=2000.0,
                    cac=600.0,
                    ltv_cac_ratio=3.3,
                    payback_period_months=8.0,
                    churn_rate_monthly=8.0,
                    churn_rate_annual=55.0,
                    net_revenue_retention=90.0,
                    gross_revenue_retention=75.0,
                    gross_margin=40.0,
                    net_margin=-70.0,
                    burn_multiple=3.0,
                    runway_months=12.0,
                    arpu_monthly=30.0,
                    conversion_rate=1.5,
                ),
                "valuation_multiple": "3-8x GMV",
                "typical_arr_range": "$0-1M"
            },
            CompanyStage.SERIES_A: {
                "metrics": MarketMetrics(
                    tam=50.0,
                    revenue_growth_mom=20.0,
                    growth_rate=200.0,
                    ltv=4000.0,
                    cac=1000.0,
                    ltv_cac_ratio=4.0,
                    payback_period_months=10.0,
                    churn_rate_monthly=6.0,
                    churn_rate_annual=45.0,
                    net_revenue_retention=95.0,
                    gross_revenue_retention=78.0,
                    gross_margin=50.0,
                    net_margin=-50.0,
                    burn_multiple=2.0,
                    runway_months=18.0,
                    arpu_monthly=50.0,
                    conversion_rate=2.0,
                ),
                "valuation_multiple": "5-12x GMV",
                "typical_arr_range": "$1M-10M"
            },
            CompanyStage.SERIES_B: {
                "metrics": MarketMetrics(
                    tam=100.0,
                    revenue_growth_mom=15.0,
                    growth_rate=120.0,
                    ltv=7000.0,
                    cac=1500.0,
                    ltv_cac_ratio=4.7,
                    payback_period_months=12.0,
                    churn_rate_monthly=5.0,
                    churn_rate_annual=40.0,
                    net_revenue_retention=100.0,
                    gross_revenue_retention=82.0,
                    gross_margin=60.0,
                    net_margin=-25.0,
                    burn_multiple=1.5,
                    runway_months=24.0,
                    rule_of_40=95.0,
                    arpu_monthly=80.0,
                    conversion_rate=3.0,
                ),
                "valuation_multiple": "8-15x GMV",
                "typical_arr_range": "$10M-50M"
            },
            CompanyStage.SERIES_C: {
                "metrics": MarketMetrics(
                    tam=200.0,
                    revenue_growth_mom=12.0,
                    growth_rate=80.0,
                    ltv=10000.0,
                    cac=2000.0,
                    ltv_cac_ratio=5.0,
                    payback_period_months=14.0,
                    churn_rate_monthly=4.0,
                    churn_rate_annual=35.0,
                    net_revenue_retention=105.0,
                    gross_revenue_retention=85.0,
                    gross_margin=65.0,
                    net_margin=-10.0,
                    burn_multiple=1.2,
                    runway_months=30.0,
                    rule_of_40=70.0,
                    arpu_monthly=100.0,
                    conversion_rate=4.0,
                ),
                "valuation_multiple": "10-20x GMV",
                "typical_arr_range": "$50M-200M"
            },
            CompanyStage.GROWTH: {
                "metrics": MarketMetrics(
                    tam=400.0,
                    revenue_growth_mom=8.0,
                    growth_rate=50.0,
                    ltv=15000.0,
                    cac=2800.0,
                    ltv_cac_ratio=5.4,
                    payback_period_months=14.0,
                    churn_rate_monthly=3.0,
                    churn_rate_annual=30.0,
                    net_revenue_retention=110.0,
                    gross_revenue_retention=88.0,
                    gross_margin=70.0,
                    net_margin=5.0,
                    burn_multiple=1.0,
                    runway_months=36.0,
                    rule_of_40=55.0,
                    arpu_monthly=150.0,
                    conversion_rate=5.0,
                ),
                "valuation_multiple": "15-25x GMV",
                "typical_arr_range": "$200M-1B"
            },
            CompanyStage.LATE_STAGE: {
                "metrics": MarketMetrics(
                    tam=800.0,
                    revenue_growth_mom=5.0,
                    growth_rate=25.0,
                    ltv=20000.0,
                    cac=3500.0,
                    ltv_cac_ratio=5.7,
                    payback_period_months=14.0,
                    churn_rate_monthly=2.5,
                    churn_rate_annual=25.0,
                    net_revenue_retention=115.0,
                    gross_revenue_retention=90.0,
                    gross_margin=75.0,
                    net_margin=15.0,
                    ebitda_margin=10.0,
                    burn_multiple=0.8,
                    runway_months=48.0,
                    rule_of_40=40.0,
                    arpu_monthly=200.0,
                    conversion_rate=6.0,
                ),
                "valuation_multiple": "20-35x GMV",
                "typical_arr_range": "$1B+"
            }
        },
        "industry_specific_metrics": {
            "take_rate": 12.0,  # % of GMV
            "buyer_seller_ratio": 10.0,
            "gmv_per_seller_monthly": 5000.0,
            "gmv_per_buyer_monthly": 200.0,
            "network_density": 0.15,
            "liquidity_metric": 0.6,  # % of listings with transactions
            "time_to_first_transaction_hours": 48.0,
            "repeat_purchase_rate": 40.0,  # %
        },
        "key_characteristics": [
            "Chicken-and-egg problem: need both buyers and sellers",
            "Network effects drive competitive moats",
            "Take rate is key monetization lever",
            "Liquidity and matching efficiency critical",
            "Geographic density often required for success"
        ]
    },
    
    # =========================================================================
    # D2C (Direct-to-Consumer)
    # =========================================================================
    "d2c": {
        "display_name": "D2C (Direct-to-Consumer)",
        "description": "Consumer brands selling directly to customers, bypassing traditional retail",
        "stages": {
            CompanyStage.SEED: {
                "metrics": MarketMetrics(
                    tam=5.0,
                    revenue_growth_mom=30.0,
                    growth_rate=400.0,
                    ltv=150.0,
                    cac=50.0,
                    ltv_cac_ratio=3.0,
                    payback_period_months=3.0,
                    churn_rate_monthly=10.0,
                    churn_rate_annual=65.0,
                    net_revenue_retention=85.0,
                    gross_revenue_retention=70.0,
                    gross_margin=50.0,
                    net_margin=-40.0,
                    burn_multiple=2.0,
                    runway_months=12.0,
                    arpu=75.0,
                    conversion_rate=2.0,
                ),
                "valuation_multiple": "1-3x Revenue",
                "typical_arr_range": "$0-2M"
            },
            CompanyStage.SERIES_A: {
                "metrics": MarketMetrics(
                    tam=15.0,
                    revenue_growth_mom=25.0,
                    growth_rate=250.0,
                    ltv=250.0,
                    cac=70.0,
                    ltv_cac_ratio=3.6,
                    payback_period_months=4.0,
                    churn_rate_monthly=8.0,
                    churn_rate_annual=55.0,
                    net_revenue_retention=90.0,
                    gross_revenue_retention=75.0,
                    gross_margin=55.0,
                    net_margin=-25.0,
                    burn_multiple=1.5,
                    runway_months=18.0,
                    arpu=100.0,
                    conversion_rate=3.0,
                ),
                "valuation_multiple": "2-5x Revenue",
                "typical_arr_range": "$2M-15M"
            },
            CompanyStage.SERIES_B: {
                "metrics": MarketMetrics(
                    tam=30.0,
                    revenue_growth_mom=20.0,
                    growth_rate=150.0,
                    ltv=400.0,
                    cac=100.0,
                    ltv_cac_ratio=4.0,
                    payback_period_months=5.0,
                    churn_rate_monthly=6.0,
                    churn_rate_annual=45.0,
                    net_revenue_retention=95.0,
                    gross_revenue_retention=80.0,
                    gross_margin=60.0,
                    net_margin=-10.0,
                    burn_multiple=1.2,
                    runway_months=24.0,
                    rule_of_40=140.0,
                    arpu=150.0,
                    conversion_rate=4.0,
                ),
                "valuation_multiple": "3-7x Revenue",
                "typical_arr_range": "$15M-75M"
            },
            CompanyStage.SERIES_C: {
                "metrics": MarketMetrics(
                    tam=60.0,
                    revenue_growth_mom=15.0,
                    growth_rate=100.0,
                    ltv=600.0,
                    cac=140.0,
                    ltv_cac_ratio=4.3,
                    payback_period_months=6.0,
                    churn_rate_monthly=5.0,
                    churn_rate_annual=40.0,
                    net_revenue_retention=100.0,
                    gross_revenue_retention=83.0,
                    gross_margin=65.0,
                    net_margin=5.0,
                    burn_multiple=1.0,
                    runway_months=30.0,
                    rule_of_40=105.0,
                    arpu=200.0,
                    conversion_rate=5.0,
                ),
                "valuation_multiple": "5-10x Revenue",
                "typical_arr_range": "$75M-300M"
            },
            CompanyStage.GROWTH: {
                "metrics": MarketMetrics(
                    tam=100.0,
                    revenue_growth_mom=10.0,
                    growth_rate=60.0,
                    ltv=800.0,
                    cac=180.0,
                    ltv_cac_ratio=4.4,
                    payback_period_months=6.0,
                    churn_rate_monthly=4.0,
                    churn_rate_annual=35.0,
                    net_revenue_retention=105.0,
                    gross_revenue_retention=85.0,
                    gross_margin=68.0,
                    net_margin=12.0,
                    burn_multiple=0.8,
                    runway_months=36.0,
                    rule_of_40=72.0,
                    arpu=250.0,
                    conversion_rate=6.0,
                ),
                "valuation_multiple": "7-15x Revenue",
                "typical_arr_range": "$300M-1B"
            },
            CompanyStage.LATE_STAGE: {
                "metrics": MarketMetrics(
                    tam=200.0,
                    revenue_growth_mom=6.0,
                    growth_rate=30.0,
                    ltv=1000.0,
                    cac=220.0,
                    ltv_cac_ratio=4.5,
                    payback_period_months=6.0,
                    churn_rate_monthly=3.0,
                    churn_rate_annual=30.0,
                    net_revenue_retention=110.0,
                    gross_revenue_retention=88.0,
                    gross_margin=70.0,
                    net_margin=18.0,
                    ebitda_margin=15.0,
                    burn_multiple=0.5,
                    runway_months=48.0,
                    rule_of_40=48.0,
                    arpu=300.0,
                    conversion_rate=7.0,
                ),
                "valuation_multiple": "10-20x Revenue",
                "typical_arr_range": "$1B+"
            }
        },
        "industry_specific_metrics": {
            "repeat_purchase_rate": 35.0,  # %
            "average_order_value": 85.0,
            "orders_per_customer_annual": 4.0,
            "customer_lifespan_months": 18.0,
            "return_rate": 15.0,  # %
            "inventory_turnover": 6.0,  # times per year
            "shipping_cost_pct": 10.0,  # % of revenue
            "marketing_spend_pct": 25.0,  # % of revenue
        },
        "key_characteristics": [
            "Brand building and storytelling are critical",
            "Customer acquisition heavily dependent on digital marketing",
            "Repeat purchase rate drives profitability",
            "Supply chain and inventory management crucial",
            "Social media presence essential for growth"
        ]
    },
    
    # =========================================================================
    # HEALTHTECH (Healthcare Technology)
    # =========================================================================
    "healthtech": {
        "display_name": "Healthtech (Healthcare Technology)",
        "description": "Technology solutions for healthcare delivery, management, and patient care",
        "stages": {
            CompanyStage.SEED: {
                "metrics": MarketMetrics(
                    tam=30.0,
                    revenue_growth_mom=15.0,
                    growth_rate=180.0,
                    ltv=8000.0,
                    cac=2500.0,
                    ltv_cac_ratio=3.2,
                    payback_period_months=18.0,
                    churn_rate_monthly=4.0,
                    churn_rate_annual=35.0,
                    net_revenue_retention=95.0,
                    gross_revenue_retention=82.0,
                    gross_margin=60.0,
                    net_margin=-70.0,
                    burn_multiple=2.5,
                    runway_months=18.0,
                    arpu_monthly=400.0,
                    conversion_rate=1.5,
                ),
                "valuation_multiple": "6-12x ARR",
                "typical_arr_range": "$0-2M"
            },
            CompanyStage.SERIES_A: {
                "metrics": MarketMetrics(
                    tam=75.0,
                    revenue_growth_mom=12.0,
                    growth_rate=120.0,
                    ltv=15000.0,
                    cac=4000.0,
                    ltv_cac_ratio=3.8,
                    payback_period_months=20.0,
                    churn_rate_monthly=3.0,
                    churn_rate_annual=30.0,
                    net_revenue_retention=100.0,
                    gross_revenue_retention=85.0,
                    gross_margin=68.0,
                    net_margin=-45.0,
                    burn_multiple=2.0,
                    runway_months=24.0,
                    arpu_monthly=600.0,
                    conversion_rate=2.0,
                ),
                "valuation_multiple": "8-15x ARR",
                "typical_arr_range": "$2M-10M"
            },
            CompanyStage.SERIES_B: {
                "metrics": MarketMetrics(
                    tam=150.0,
                    revenue_growth_mom=10.0,
                    growth_rate=80.0,
                    ltv=25000.0,
                    cac=6000.0,
                    ltv_cac_ratio=4.2,
                    payback_period_months=22.0,
                    churn_rate_monthly=2.5,
                    churn_rate_annual=25.0,
                    net_revenue_retention=105.0,
                    gross_revenue_retention=88.0,
                    gross_margin=72.0,
                    net_margin=-25.0,
                    burn_multiple=1.5,
                    runway_months=30.0,
                    rule_of_40=55.0,
                    arpu_monthly=800.0,
                    conversion_rate=2.5,
                ),
                "valuation_multiple": "10-20x ARR",
                "typical_arr_range": "$10M-50M"
            },
            CompanyStage.SERIES_C: {
                "metrics": MarketMetrics(
                    tam=300.0,
                    revenue_growth_mom=8.0,
                    growth_rate=50.0,
                    ltv=35000.0,
                    cac=8000.0,
                    ltv_cac_ratio=4.4,
                    payback_period_months=24.0,
                    churn_rate_monthly=2.0,
                    churn_rate_annual=20.0,
                    net_revenue_retention=110.0,
                    gross_revenue_retention=90.0,
                    gross_margin=75.0,
                    net_margin=-10.0,
                    burn_multiple=1.2,
                    runway_months=36.0,
                    rule_of_40=40.0,
                    arpu_monthly=1000.0,
                    conversion_rate=3.0,
                ),
                "valuation_multiple": "15-25x ARR",
                "typical_arr_range": "$50M-200M"
            },
            CompanyStage.GROWTH: {
                "metrics": MarketMetrics(
                    tam=500.0,
                    revenue_growth_mom=6.0,
                    growth_rate=35.0,
                    ltv=50000.0,
                    cac=10000.0,
                    ltv_cac_ratio=5.0,
                    payback_period_months=24.0,
                    churn_rate_monthly=1.5,
                    churn_rate_annual=15.0,
                    net_revenue_retention=115.0,
                    gross_revenue_retention=92.0,
                    gross_margin=78.0,
                    net_margin=8.0,
                    burn_multiple=1.0,
                    runway_months=42.0,
                    rule_of_40=43.0,
                    arpu_monthly=1200.0,
                    conversion_rate=3.5,
                ),
                "valuation_multiple": "20-30x ARR",
                "typical_arr_range": "$200M-1B"
            },
            CompanyStage.LATE_STAGE: {
                "metrics": MarketMetrics(
                    tam=1000.0,
                    revenue_growth_mom=4.0,
                    growth_rate=20.0,
                    ltv=70000.0,
                    cac=12000.0,
                    ltv_cac_ratio=5.8,
                    payback_period_months=24.0,
                    churn_rate_monthly=1.0,
                    churn_rate_annual=10.0,
                    net_revenue_retention=120.0,
                    gross_revenue_retention=95.0,
                    gross_margin=80.0,
                    net_margin=15.0,
                    ebitda_margin=12.0,
                    burn_multiple=0.8,
                    runway_months=48.0,
                    rule_of_40=35.0,
                    arpu_monthly=1500.0,
                    conversion_rate=4.0,
                ),
                "valuation_multiple": "25-40x ARR",
                "typical_arr_range": "$1B+"
            }
        },
        "industry_specific_metrics": {
            "patient_engagement_rate": 60.0,  # %
            "provider_adoption_rate": 45.0,  # %
            "hipaa_compliance_cost_pct": 5.0,
            "clinical_outcomes_improvement": 15.0,  # %
            "patient_satisfaction_score": 4.2,  # out of 5
            "time_to_clinical_validation_months": 18.0,
            "regulatory_approval_timeline_months": 24.0,
            "reimbursement_rate": 70.0,  # %
        },
        "key_characteristics": [
            "Highly regulated with HIPAA, FDA requirements",
            "Long sales cycles due to healthcare decision-making",
            "Clinical validation and evidence required",
            "Integration with existing health systems critical",
            "Patient outcomes and safety paramount"
        ]
    },
    
    # =========================================================================
    # CONSUMER_SUBSCRIPTIONS
    # =========================================================================
    "consumer_subscriptions": {
        "display_name": "Consumer Subscriptions",
        "description": "B2C subscription services including streaming, fitness, meal kits, etc.",
        "stages": {
            CompanyStage.SEED: {
                "metrics": MarketMetrics(
                    tam=10.0,
                    revenue_growth_mom=20.0,
                    growth_rate=250.0,
                    ltv=300.0,
                    cac=80.0,
                    ltv_cac_ratio=3.8,
                    payback_period_months=4.0,
                    churn_rate_monthly=8.0,
                    churn_rate_annual=55.0,
                    net_revenue_retention=90.0,
                    gross_revenue_retention=75.0,
                    gross_margin=65.0,
                    net_margin=-50.0,
                    burn_multiple=2.0,
                    runway_months=15.0,
                    arpu_monthly=25.0,
                    conversion_rate=3.0,
                ),
                "valuation_multiple": "4-8x ARR",
                "typical_arr_range": "$0-2M"
            },
            CompanyStage.SERIES_A: {
                "metrics": MarketMetrics(
                    tam=25.0,
                    revenue_growth_mom=15.0,
                    growth_rate=150.0,
                    ltv=500.0,
                    cac=120.0,
                    ltv_cac_ratio=4.2,
                    payback_period_months=5.0,
                    churn_rate_monthly=6.0,
                    churn_rate_annual=45.0,
                    net_revenue_retention=95.0,
                    gross_revenue_retention=80.0,
                    gross_margin=70.0,
                    net_margin=-30.0,
                    burn_multiple=1.5,
                    runway_months=20.0,
                    arpu_monthly=35.0,
                    conversion_rate=4.0,
                ),
                "valuation_multiple": "6-12x ARR",
                "typical_arr_range": "$2M-15M"
            },
            CompanyStage.SERIES_B: {
                "metrics": MarketMetrics(
                    tam=50.0,
                    revenue_growth_mom=12.0,
                    growth_rate=100.0,
                    ltv=800.0,
                    cac=180.0,
                    ltv_cac_ratio=4.4,
                    payback_period_months=6.0,
                    churn_rate_monthly=5.0,
                    churn_rate_annual=40.0,
                    net_revenue_retention=100.0,
                    gross_revenue_retention=83.0,
                    gross_margin=72.0,
                    net_margin=-15.0,
                    burn_multiple=1.2,
                    runway_months=24.0,
                    rule_of_40=85.0,
                    arpu_monthly=45.0,
                    conversion_rate=5.0,
                ),
                "valuation_multiple": "8-15x ARR",
                "typical_arr_range": "$15M-75M"
            },
            CompanyStage.SERIES_C: {
                "metrics": MarketMetrics(
                    tam=100.0,
                    revenue_growth_mom=10.0,
                    growth_rate=60.0,
                    ltv=1200.0,
                    cac=250.0,
                    ltv_cac_ratio=4.8,
                    payback_period_months=7.0,
                    churn_rate_monthly=4.0,
                    churn_rate_annual=35.0,
                    net_revenue_retention=105.0,
                    gross_revenue_retention=86.0,
                    gross_margin=75.0,
                    net_margin=0.0,
                    burn_multiple=1.0,
                    runway_months=30.0,
                    rule_of_40=60.0,
                    arpu_monthly=55.0,
                    conversion_rate=6.0,
                ),
                "valuation_multiple": "12-20x ARR",
                "typical_arr_range": "$75M-300M"
            },
            CompanyStage.GROWTH: {
                "metrics": MarketMetrics(
                    tam=200.0,
                    revenue_growth_mom=7.0,
                    growth_rate=40.0,
                    ltv=1500.0,
                    cac=300.0,
                    ltv_cac_ratio=5.0,
                    payback_period_months=7.0,
                    churn_rate_monthly=3.0,
                    churn_rate_annual=30.0,
                    net_revenue_retention=110.0,
                    gross_revenue_retention=88.0,
                    gross_margin=78.0,
                    net_margin=10.0,
                    burn_multiple=0.8,
                    runway_months=36.0,
                    rule_of_40=50.0,
                    arpu_monthly=65.0,
                    conversion_rate=7.0,
                ),
                "valuation_multiple": "15-25x ARR",
                "typical_arr_range": "$300M-1B"
            },
            CompanyStage.LATE_STAGE: {
                "metrics": MarketMetrics(
                    tam=400.0,
                    revenue_growth_mom=4.0,
                    growth_rate=20.0,
                    ltv=2000.0,
                    cac=350.0,
                    ltv_cac_ratio=5.7,
                    payback_period_months=7.0,
                    churn_rate_monthly=2.0,
                    churn_rate_annual=20.0,
                    net_revenue_retention=115.0,
                    gross_revenue_retention=90.0,
                    gross_margin=80.0,
                    net_margin=18.0,
                    ebitda_margin=15.0,
                    burn_multiple=0.5,
                    runway_months=48.0,
                    rule_of_40=38.0,
                    arpu_monthly=80.0,
                    conversion_rate=8.0,
                ),
                "valuation_multiple": "20-35x ARR",
                "typical_arr_range": "$1B+"
            }
        },
        "industry_specific_metrics": {
            "monthly_active_subscribers_pct": 75.0,
            "free_to_paid_conversion": 8.0,  # %
            "content_engagement_hours_monthly": 12.0,
            "subscription_pause_rate": 15.0,  # %
            "upgrade_rate": 10.0,  # %
            "downgrade_rate": 5.0,  # %
            "average_subscription_length_months": 24.0,
            "family_plan_adoption": 25.0,  # %
        },
        "key_characteristics": [
            "Content and engagement drive retention",
            "Low price point requires high volume",
            "Churn management is critical challenge",
            "Free trials and freemium common strategies",
            "Customer lifetime value highly variable"
        ]
    },
    
    # =========================================================================
    # HARDWARE
    # =========================================================================
    "hardware": {
        "display_name": "Hardware",
        "description": "Physical technology products including IoT, consumer electronics, robotics",
        "stages": {
            CompanyStage.SEED: {
                "metrics": MarketMetrics(
                    tam=5.0,
                    revenue_growth_mom=15.0,
                    growth_rate=150.0,
                    ltv=500.0,
                    cac=200.0,
                    ltv_cac_ratio=2.5,
                    payback_period_months=8.0,
                    churn_rate_monthly=3.0,
                    churn_rate_annual=30.0,
                    net_revenue_retention=95.0,
                    gross_revenue_retention=88.0,
                    gross_margin=35.0,
                    net_margin=-80.0,
                    burn_multiple=3.0,
                    runway_months=12.0,
                    arpu=300.0,
                    conversion_rate=1.5,
                ),
                "valuation_multiple": "2-5x Revenue",
                "typical_arr_range": "$0-3M"
            },
            CompanyStage.SERIES_A: {
                "metrics": MarketMetrics(
                    tam=15.0,
                    revenue_growth_mom=12.0,
                    growth_rate=100.0,
                    ltv=800.0,
                    cac=280.0,
                    ltv_cac_ratio=2.9,
                    payback_period_months=10.0,
                    churn_rate_monthly=2.5,
                    churn_rate_annual=25.0,
                    net_revenue_retention=100.0,
                    gross_revenue_retention=90.0,
                    gross_margin=40.0,
                    net_margin=-50.0,
                    burn_multiple=2.0,
                    runway_months=18.0,
                    arpu=450.0,
                    conversion_rate=2.0,
                ),
                "valuation_multiple": "3-7x Revenue",
                "typical_arr_range": "$3M-20M"
            },
            CompanyStage.SERIES_B: {
                "metrics": MarketMetrics(
                    tam=30.0,
                    revenue_growth_mom=10.0,
                    growth_rate=70.0,
                    ltv=1200.0,
                    cac=380.0,
                    ltv_cac_ratio=3.2,
                    payback_period_months=12.0,
                    churn_rate_monthly=2.0,
                    churn_rate_annual=20.0,
                    net_revenue_retention=105.0,
                    gross_revenue_retention=92.0,
                    gross_margin=45.0,
                    net_margin=-30.0,
                    burn_multiple=1.5,
                    runway_months=24.0,
                    arpu=600.0,
                    conversion_rate=2.5,
                ),
                "valuation_multiple": "5-10x Revenue",
                "typical_arr_range": "$20M-100M"
            },
            CompanyStage.SERIES_C: {
                "metrics": MarketMetrics(
                    tam=60.0,
                    revenue_growth_mom=8.0,
                    growth_rate=50.0,
                    ltv=1600.0,
                    cac=480.0,
                    ltv_cac_ratio=3.3,
                    payback_period_months=14.0,
                    churn_rate_monthly=1.5,
                    churn_rate_annual=15.0,
                    net_revenue_retention=110.0,
                    gross_revenue_retention=94.0,
                    gross_margin=48.0,
                    net_margin=-10.0,
                    burn_multiple=1.2,
                    runway_months=30.0,
                    arpu=750.0,
                    conversion_rate=3.0,
                ),
                "valuation_multiple": "7-12x Revenue",
                "typical_arr_range": "$100M-400M"
            },
            CompanyStage.GROWTH: {
                "metrics": MarketMetrics(
                    tam=100.0,
                    revenue_growth_mom=6.0,
                    growth_rate=30.0,
                    ltv=2000.0,
                    cac=580.0,
                    ltv_cac_ratio=3.4,
                    payback_period_months=14.0,
                    churn_rate_monthly=1.0,
                    churn_rate_annual=10.0,
                    net_revenue_retention=115.0,
                    gross_revenue_retention=95.0,
                    gross_margin=50.0,
                    net_margin=5.0,
                    burn_multiple=1.0,
                    runway_months=36.0,
                    arpu=900.0,
                    conversion_rate=3.5,
                ),
                "valuation_multiple": "10-15x Revenue",
                "typical_arr_range": "$400M-2B"
            },
            CompanyStage.LATE_STAGE: {
                "metrics": MarketMetrics(
                    tam=200.0,
                    revenue_growth_mom=4.0,
                    growth_rate=15.0,
                    ltv=2500.0,
                    cac=680.0,
                    ltv_cac_ratio=3.7,
                    payback_period_months=14.0,
                    churn_rate_monthly=0.8,
                    churn_rate_annual=8.0,
                    net_revenue_retention=120.0,
                    gross_revenue_retention=96.0,
                    gross_margin=52.0,
                    net_margin=12.0,
                    ebitda_margin=8.0,
                    burn_multiple=0.8,
                    runway_months=48.0,
                    arpu=1000.0,
                    conversion_rate=4.0,
                ),
                "valuation_multiple": "12-20x Revenue",
                "typical_arr_range": "$2B+"
            }
        },
        "industry_specific_metrics": {
            "cost_of_goods_sold_pct": 55.0,  # %
            "inventory_turnover": 4.0,  # times per year
            "warranty_claim_rate": 3.0,  # %
            "return_rate": 8.0,  # %
            "r_and_d_spend_pct": 15.0,  # % of revenue
            "manufacturing_lead_time_weeks": 12.0,
            "product_lifecycle_months": 36.0,
            "service_attachment_rate": 25.0,  # %
        },
        "key_characteristics": [
            "Capital intensive with high upfront costs",
            "Lower gross margins due to COGS",
            "Supply chain management critical",
            "Longer development and manufacturing cycles",
            "Service and support revenue important"
        ]
    },
    
    # =========================================================================
    # SERVICES
    # =========================================================================
    "services": {
        "display_name": "Services",
        "description": "Professional and business services including consulting, agencies, outsourcing",
        "stages": {
            CompanyStage.SEED: {
                "metrics": MarketMetrics(
                    tam=3.0,
                    revenue_growth_mom=10.0,
                    growth_rate=100.0,
                    ltv=10000.0,
                    cac=3000.0,
                    ltv_cac_ratio=3.3,
                    payback_period_months=6.0,
                    churn_rate_monthly=5.0,
                    churn_rate_annual=45.0,
                    net_revenue_retention=90.0,
                    gross_revenue_retention=80.0,
                    gross_margin=45.0,
                    net_margin=-20.0,
                    burn_multiple=1.5,
                    runway_months=12.0,
                    arpu=5000.0,
                    conversion_rate=5.0,
                ),
                "valuation_multiple": "1-2x Revenue",
                "typical_arr_range": "$0-1M"
            },
            CompanyStage.SERIES_A: {
                "metrics": MarketMetrics(
                    tam=8.0,
                    revenue_growth_mom=8.0,
                    growth_rate=70.0,
                    ltv=20000.0,
                    cac=5000.0,
                    ltv_cac_ratio=4.0,
                    payback_period_months=8.0,
                    churn_rate_monthly=4.0,
                    churn_rate_annual=40.0,
                    net_revenue_retention=95.0,
                    gross_revenue_retention=83.0,
                    gross_margin=50.0,
                    net_margin=-10.0,
                    burn_multiple=1.2,
                    runway_months=18.0,
                    arpu=8000.0,
                    conversion_rate=6.0,
                ),
                "valuation_multiple": "1.5-3x Revenue",
                "typical_arr_range": "$1M-10M"
            },
            CompanyStage.SERIES_B: {
                "metrics": MarketMetrics(
                    tam=15.0,
                    revenue_growth_mom=6.0,
                    growth_rate=50.0,
                    ltv=35000.0,
                    cac=8000.0,
                    ltv_cac_ratio=4.4,
                    payback_period_months=10.0,
                    churn_rate_monthly=3.0,
                    churn_rate_annual=35.0,
                    net_revenue_retention=100.0,
                    gross_revenue_retention=86.0,
                    gross_margin=52.0,
                    net_margin=5.0,
                    burn_multiple=1.0,
                    runway_months=24.0,
                    arpu=12000.0,
                    conversion_rate=7.0,
                ),
                "valuation_multiple": "2-4x Revenue",
                "typical_arr_range": "$10M-50M"
            },
            CompanyStage.SERIES_C: {
                "metrics": MarketMetrics(
                    tam=30.0,
                    revenue_growth_mom=5.0,
                    growth_rate=35.0,
                    ltv=50000.0,
                    cac=11000.0,
                    ltv_cac_ratio=4.5,
                    payback_period_months=12.0,
                    churn_rate_monthly=2.5,
                    churn_rate_annual=30.0,
                    net_revenue_retention=105.0,
                    gross_revenue_retention=88.0,
                    gross_margin=55.0,
                    net_margin=10.0,
                    burn_multiple=0.8,
                    runway_months=30.0,
                    arpu=15000.0,
                    conversion_rate=8.0,
                ),
                "valuation_multiple": "3-5x Revenue",
                "typical_arr_range": "$50M-200M"
            },
            CompanyStage.GROWTH: {
                "metrics": MarketMetrics(
                    tam=50.0,
                    revenue_growth_mom=4.0,
                    growth_rate=25.0,
                    ltv=70000.0,
                    cac=15000.0,
                    ltv_cac_ratio=4.7,
                    payback_period_months=12.0,
                    churn_rate_monthly=2.0,
                    churn_rate_annual=25.0,
                    net_revenue_retention=110.0,
                    gross_revenue_retention=90.0,
                    gross_margin=58.0,
                    net_margin=15.0,
                    burn_multiple=0.6,
                    runway_months=36.0,
                    arpu=20000.0,
                    conversion_rate=9.0,
                ),
                "valuation_multiple": "4-7x Revenue",
                "typical_arr_range": "$200M-1B"
            },
            CompanyStage.LATE_STAGE: {
                "metrics": MarketMetrics(
                    tam=100.0,
                    revenue_growth_mom=3.0,
                    growth_rate=15.0,
                    ltv=100000.0,
                    cac=20000.0,
                    ltv_cac_ratio=5.0,
                    payback_period_months=12.0,
                    churn_rate_monthly=1.5,
                    churn_rate_annual=20.0,
                    net_revenue_retention=115.0,
                    gross_revenue_retention=92.0,
                    gross_margin=60.0,
                    net_margin=20.0,
                    ebitda_margin=18.0,
                    burn_multiple=0.5,
                    runway_months=48.0,
                    arpu=25000.0,
                    conversion_rate=10.0,
                ),
                "valuation_multiple": "5-10x Revenue",
                "typical_arr_range": "$1B+"
            }
        },
        "industry_specific_metrics": {
            "utilization_rate": 75.0,  # % billable hours
            "average_project_size": 50000.0,
            "project_duration_weeks": 12.0,
            "client_concentration_top_5_pct": 40.0,
            "employee_turnover_rate": 20.0,  # % annually
            "revenue_per_employee": 150000.0,
            "billable_rate_hourly": 150.0,
            "project_margin": 35.0,  # %
        },
        "key_characteristics": [
            "People-intensive with lower scalability",
            "Lower valuation multiples than tech companies",
            "Client relationships and reputation critical",
            "Utilization rates drive profitability",
            "Revenue per employee key efficiency metric"
        ]
    }
}


# =============================================================================
# MARKET AGENT CLASS
# =============================================================================

class MarketAgent:
    """
    Market Intelligence Agent for startup analysis and competitive positioning.
    
    Provides comprehensive market analysis capabilities including:
    - Industry benchmark comparisons
    - Market sizing calculations
    - Competitive positioning analysis
    - Stage-appropriate metric evaluation
    - Industry-specific insights
    """
    
    def __init__(self):
        """Initialize the Market Agent with industry benchmarks."""
        self.benchmarks = INDUSTRY_BENCHMARKS
        self.stages = list(CompanyStage)
        self.positions = list(MarketPosition)
    
    # =====================================================================
    # INDUSTRY INFORMATION METHODS
    # =====================================================================
    
    def get_available_industries(self) -> List[str]:
        """Get list of available industry keys."""
        return list(self.benchmarks.keys())
    
    def get_industry_info(self, industry: str) -> Dict[str, Any]:
        """
        Get comprehensive information about an industry.
        
        Args:
            industry: Industry key (e.g., 'saas', 'fintech')
            
        Returns:
            Dictionary with industry display name, description, and characteristics
        """
        if industry not in self.benchmarks:
            raise ValueError(f"Industry '{industry}' not found. Available: {self.get_available_industries()}")
        
        data = self.benchmarks[industry]
        return {
            "key": industry,
            "display_name": data["display_name"],
            "description": data["description"],
            "key_characteristics": data["key_characteristics"],
            "stages_available": [s.value for s in data["stages"].keys()]
        }
    
    def get_industry_metrics(self, industry: str, stage: CompanyStage) -> MarketMetrics:
        """
        Get benchmark metrics for a specific industry and stage.
        
        Args:
            industry: Industry key
            stage: Company stage enum
            
        Returns:
            MarketMetrics object with benchmark values
        """
        if industry not in self.benchmarks:
            raise ValueError(f"Industry '{industry}' not found")
        
        stage_data = self.benchmarks[industry]["stages"].get(stage)
        if not stage_data:
            raise ValueError(f"Stage '{stage.value}' not available for industry '{industry}'")
        
        return stage_data["metrics"]
    
    def get_valuation_multiple(self, industry: str, stage: CompanyStage) -> str:
        """Get typical valuation multiple for industry and stage."""
        if industry not in self.benchmarks:
            raise ValueError(f"Industry '{industry}' not found")
        
        stage_data = self.benchmarks[industry]["stages"].get(stage)
        if not stage_data:
            return "N/A"
        
        return stage_data.get("valuation_multiple", "N/A")
    
    def get_typical_arr_range(self, industry: str, stage: CompanyStage) -> str:
        """Get typical ARR range for industry and stage."""
        if industry not in self.benchmarks:
            raise ValueError(f"Industry '{industry}' not found")
        
        stage_data = self.benchmarks[industry]["stages"].get(stage)
        if not stage_data:
            return "N/A"
        
        return stage_data.get("typical_arr_range", "N/A")
    
    # =====================================================================
    # BENCHMARK COMPARISON METHODS
    # =====================================================================
    
    def compare_to_benchmark(
        self, 
        industry: str, 
        stage: CompanyStage, 
        company_metrics: Dict[str, float]
    ) -> Dict[str, Any]:
        """
        Compare company metrics to industry benchmarks.
        
        Args:
            industry: Industry key
            stage: Company stage
            company_metrics: Dictionary of company metric values
            
        Returns:
            Comparison results with status (above/below/at) and percentiles
        """
        benchmark = self.get_industry_metrics(industry, stage)
        benchmark_dict = benchmark.to_dict()
        
        results = {}
        for metric_name, company_value in company_metrics.items():
            if metric_name in benchmark_dict and benchmark_dict[metric_name] is not None:
                benchmark_value = benchmark_dict[metric_name]
                
                # Calculate percentage difference
                if benchmark_value != 0:
                    pct_diff = ((company_value - benchmark_value) / abs(benchmark_value)) * 100
                else:
                    pct_diff = 0 if company_value == 0 else float('inf')
                
                # Determine status
                # For metrics where lower is better
                lower_is_better = metric_name in [
                    'churn_rate_monthly', 'churn_rate_annual', 
                    'cac', 'burn_multiple', 'payback_period_months'
                ]
                
                if lower_is_better:
                    if company_value < benchmark_value * 0.9:
                        status = "above"
                    elif company_value > benchmark_value * 1.1:
                        status = "below"
                    else:
                        status = "at"
                else:
                    if company_value > benchmark_value * 1.1:
                        status = "above"
                    elif company_value < benchmark_value * 0.9:
                        status = "below"
                    else:
                        status = "at"
                
                results[metric_name] = {
                    "company_value": company_value,
                    "benchmark_value": benchmark_value,
                    "percent_diff": round(pct_diff, 2),
                    "status": status
                }
        
        return results
    
    def get_metric_percentile(
        self, 
        industry: str, 
        stage: CompanyStage, 
        metric_name: str, 
        value: float
    ) -> Dict[str, Any]:
        """
        Estimate the percentile of a metric value relative to benchmarks.
        
        Args:
            industry: Industry key
            stage: Company stage
            metric_name: Metric to evaluate
            value: Company metric value
            
        Returns:
            Dictionary with percentile estimate and interpretation
        """
        benchmark = self.get_industry_metrics(industry, stage)
        benchmark_value = getattr(benchmark, metric_name, None)
        
        if benchmark_value is None:
            return {"error": f"Metric '{metric_name}' not available for {industry} at {stage.value}"}
        
        # Simple percentile estimation based on benchmark as median (50th)
        # This is a simplified model - real percentiles would require distribution data
        if benchmark_value > 0:
            ratio = value / benchmark_value
            # Map ratio to percentile (simplified)
            if ratio >= 2.0:
                percentile = 95
            elif ratio >= 1.5:
                percentile = 85
            elif ratio >= 1.2:
                percentile = 75
            elif ratio >= 1.1:
                percentile = 60
            elif ratio >= 0.9:
                percentile = 50
            elif ratio >= 0.8:
                percentile = 40
            elif ratio >= 0.6:
                percentile = 25
            elif ratio >= 0.4:
                percentile = 15
            else:
                percentile = 5
        else:
            percentile = 50
        
        interpretation = self._interpret_percentile(percentile, metric_name)
        
        return {
            "metric": metric_name,
            "value": value,
            "benchmark_median": benchmark_value,
            "estimated_percentile": percentile,
            "interpretation": interpretation
        }
    
    def _interpret_percentile(self, percentile: int, metric_name: str) -> str:
        """Provide interpretation of percentile for a metric."""
        lower_is_better = metric_name in [
            'churn_rate_monthly', 'churn_rate_annual', 
            'cac', 'burn_multiple', 'payback_period_months'
        ]
        
        if lower_is_better:
            if percentile <= 25:
                return "Excellent - top quartile performance"
            elif percentile <= 50:
                return "Good - above median performance"
            elif percentile <= 75:
                return "Average - median performance"
            else:
                return "Below average - needs improvement"
        else:
            if percentile >= 75:
                return "Excellent - top quartile performance"
            elif percentile >= 50:
                return "Good - above median performance"
            elif percentile >= 25:
                return "Average - median performance"
            else:
                return "Below average - needs improvement"
    
    # =====================================================================
    # COMPETITIVE POSITIONING METHODS
    # =====================================================================
    
    def get_competitive_position(
        self, 
        industry: str, 
        stage: CompanyStage, 
        company_metrics: Dict[str, float]
    ) -> Dict[str, Any]:
        """
        Determine competitive market position based on metrics.
        
        Args:
            industry: Industry key
            stage: Company stage
            company_metrics: Company performance metrics
            
        Returns:
            Position assessment with strengths and improvement areas
        """
        comparison = self.compare_to_benchmark(industry, stage, company_metrics)
        
        # Count metrics above/below benchmark
        above_count = sum(1 for r in comparison.values() if r["status"] == "above")
        below_count = sum(1 for r in comparison.values() if r["status"] == "below")
        total_count = len(comparison)
        
        # Determine position
        if total_count == 0:
            position = MarketPosition.EMERGING
        else:
            above_ratio = above_count / total_count
            below_ratio = below_count / total_count
            
            if above_ratio >= 0.7:
                position = MarketPosition.LEADER
            elif above_ratio >= 0.5:
                position = MarketPosition.CHALLENGER
            elif below_ratio >= 0.6:
                position = MarketPosition.FOLLOWER
            elif above_ratio >= 0.3:
                position = MarketPosition.NICHE
            else:
                position = MarketPosition.EMERGING
        
        # Identify strengths and weaknesses
        strengths = []
        improvements = []
        
        for metric, result in comparison.items():
            if result["status"] == "above":
                strengths.append(f"{metric}: {result['percent_diff']:+.1f}% vs benchmark")
            elif result["status"] == "below":
                improvements.append(f"{metric}: {result['percent_diff']:+.1f}% vs benchmark")
        
        return {
            "position": position.value,
            "position_description": self._get_position_description(position),
            "metrics_evaluated": total_count,
            "metrics_above_benchmark": above_count,
            "metrics_below_benchmark": below_count,
            "strengths": strengths[:5],  # Top 5 strengths
            "improvement_areas": improvements[:5],  # Top 5 areas for improvement
            "detailed_comparison": comparison
        }
    
    def _get_position_description(self, position: MarketPosition) -> str:
        """Get description for a market position."""
        descriptions = {
            MarketPosition.LEADER: "Market leader with strong performance across key metrics",
            MarketPosition.CHALLENGER: "Strong challenger with competitive metrics in most areas",
            MarketPosition.FOLLOWER: "Market follower with room for improvement",
            MarketPosition.NICHE: "Niche player with specialized strengths",
            MarketPosition.EMERGING: "Emerging player still establishing market position"
        }
        return descriptions.get(position, "Unknown position")
    
    def get_competitive_analysis(
        self, 
        industry: str, 
        stage: CompanyStage,
        company_metrics: Dict[str, float],
        competitors: Optional[List[Dict[str, float]]] = None
    ) -> Dict[str, Any]:
        """
        Comprehensive competitive analysis including peer comparison.
        
        Args:
            industry: Industry key
            stage: Company stage
            company_metrics: Company metrics
            competitors: Optional list of competitor metrics for comparison
            
        Returns:
            Full competitive analysis report
        """
        # Get benchmark comparison
        benchmark_comparison = self.compare_to_benchmark(industry, stage, company_metrics)
        
        # Get positioning
        positioning = self.get_competitive_position(industry, stage, company_metrics)
        
        # Get industry info
        industry_info = self.get_industry_info(industry)
        
        # Calculate key metrics summary
        key_metrics_summary = self._summarize_key_metrics(company_metrics, benchmark_comparison)
        
        analysis = {
            "industry": industry_info,
            "stage": stage.value,
            "positioning": positioning,
            "key_metrics_summary": key_metrics_summary,
            "benchmark_comparison": benchmark_comparison,
            "valuation_context": {
                "typical_multiple": self.get_valuation_multiple(industry, stage),
                "typical_arr_range": self.get_typical_arr_range(industry, stage)
            }
        }
        
        # Add competitor comparison if provided
        if competitors:
            analysis["competitor_comparison"] = self._compare_to_competitors(
                company_metrics, competitors
            )
        
        return analysis
    
    def _summarize_key_metrics(
        self, 
        company_metrics: Dict[str, float], 
        comparison: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Create summary of key performance metrics."""
        key_metrics = [
            'revenue_growth_mom', 'growth_rate', 'ltv_cac_ratio',
            'churn_rate_monthly', 'net_revenue_retention', 
            'gross_margin', 'burn_multiple', 'rule_of_40'
        ]
        
        summary = {}
        for metric in key_metrics:
            if metric in company_metrics and metric in comparison:
                summary[metric] = {
                    "value": company_metrics[metric],
                    "benchmark": comparison[metric]["benchmark_value"],
                    "status": comparison[metric]["status"],
                    "percent_diff": comparison[metric]["percent_diff"]
                }
        
        return summary
    
    def _compare_to_competitors(
        self, 
        company_metrics: Dict[str, float], 
        competitors: List[Dict[str, float]]
    ) -> Dict[str, Any]:
        """Compare company metrics to competitor metrics."""
        comparisons = []
        
        for i, competitor in enumerate(competitors):
            comp_comparison = {}
            for metric, company_value in company_metrics.items():
                if metric in competitor:
                    comp_value = competitor[metric]
                    if comp_value != 0:
                        pct_diff = ((company_value - comp_value) / abs(comp_value)) * 100
                    else:
                        pct_diff = 0
                    comp_comparison[metric] = {
                        "company": company_value,
                        "competitor": comp_value,
                        "percent_diff": round(pct_diff, 2)
                    }
            comparisons.append({
                "competitor_id": i + 1,
                "comparison": comp_comparison
            })
        
        return {
            "num_competitors": len(competitors),
            "comparisons": comparisons
        }
    
    # =====================================================================
    # MARKET SIZING METHODS
    # =====================================================================
    
    def calculate_market_share(
        self, 
        company_revenue: float, 
        market_size: float
    ) -> Dict[str, float]:
        """
        Calculate market share metrics.
        
        Args:
            company_revenue: Company annual revenue
            market_size: Total market size (TAM, SAM, or SOM)
            
        Returns:
            Market share analysis
        """
        if market_size <= 0:
            return {"error": "Market size must be positive"}
        
        market_share_pct = (company_revenue / market_size) * 100
        
        # Categorize market position by share
        if market_share_pct >= 20:
            category = "Dominant"
        elif market_share_pct >= 10:
            category = "Strong"
        elif market_share_pct >= 5:
            category = "Moderate"
        elif market_share_pct >= 1:
            category = "Niche"
        else:
            category = "Emerging"
        
        return {
            "company_revenue": company_revenue,
            "market_size": market_size,
            "market_share_pct": round(market_share_pct, 4),
            "market_position_category": category,
            "revenue_to_1pct_share": round(market_size * 0.01, 2),
            "revenue_to_5pct_share": round(market_size * 0.05, 2),
            "revenue_to_10pct_share": round(market_size * 0.10, 2)
        }
    
    def get_market_sizing_template(self, industry: str) -> Dict[str, Any]:
        """
        Get market sizing template for an industry.
        
        Args:
            industry: Industry key
            
        Returns:
            Market sizing framework with typical ranges
        """
        if industry not in self.benchmarks:
            raise ValueError(f"Industry '{industry}' not found")
        
        # Get TAM from late stage as proxy for total market
        late_stage_metrics = self.get_industry_metrics(industry, CompanyStage.LATE_STAGE)
        
        return {
            "industry": industry,
            "tam_template": {
                "description": "Total Addressable Market - total demand for product/service",
                "typical_range_billions": f"${late_stage_metrics.tam * 0.5:.0f}B - ${late_stage_metrics.tam * 2:.0f}B",
                "calculation_methods": [
                    "Top-down: Industry reports and analyst estimates",
                    "Bottom-up: Price × Total potential customers",
                    "Value-theory: Value created × Willingness to pay"
                ]
            },
            "sam_template": {
                "description": "Serviceable Addressable Market - reachable with business model",
                "typical_pct_of_tam": "20-40%",
                "factors": [
                    "Geographic reach",
                    "Customer segment focus",
                    "Distribution channel constraints",
                    "Regulatory limitations"
                ]
            },
            "som_template": {
                "description": "Serviceable Obtainable Market - realistically achievable in near term",
                "typical_pct_of_sam": "10-20%",
                "factors": [
                    "Competitive landscape",
                    "Go-to-market capacity",
                    "Brand awareness",
                    "Sales and marketing resources"
                ]
            }
        }
    
    # =====================================================================
    # INDUSTRY INSIGHTS METHODS
    # =====================================================================
    
    def get_industry_insights(self, industry: str) -> Dict[str, Any]:
        """
        Get comprehensive industry insights and trends.
        
        Args:
            industry: Industry key
            
        Returns:
            Industry insights including trends, key metrics, and characteristics
        """
        if industry not in self.benchmarks:
            raise ValueError(f"Industry '{industry}' not found")
        
        data = self.benchmarks[industry]
        
        # Collect metrics across stages for trend analysis
        stage_metrics = {}
        for stage, stage_data in data["stages"].items():
            stage_metrics[stage.value] = {
                "growth_rate": stage_data["metrics"].growth_rate,
                "ltv_cac_ratio": stage_data["metrics"].ltv_cac_ratio,
                "gross_margin": stage_data["metrics"].gross_margin,
                "churn_rate_annual": stage_data["metrics"].churn_rate_annual,
                "valuation_multiple": stage_data.get("valuation_multiple", "N/A")
            }
        
        return {
            "industry": industry,
            "display_name": data["display_name"],
            "description": data["description"],
            "key_characteristics": data["key_characteristics"],
            "industry_specific_metrics": data.get("industry_specific_metrics", {}),
            "stage_evolution": stage_metrics,
            "key_success_factors": self._get_success_factors(industry),
            "common_challenges": self._get_common_challenges(industry)
        }
    
    def _get_success_factors(self, industry: str) -> List[str]:
        """Get key success factors for an industry."""
        factors = {
            "saas": [
                "Product-market fit and user engagement",
                "Efficient customer acquisition with strong LTV/CAC",
                "Low churn and high net revenue retention",
                "Scalable infrastructure and operations",
                "Strong product-led growth motion"
            ],
            "fintech": [
                "Regulatory compliance and trust",
                "Secure and reliable technology infrastructure",
                "Efficient customer acquisition partnerships",
                "Strong risk management and fraud prevention",
                "User experience and convenience"
            ],
            "marketplace": [
                "Achieving liquidity and network effects",
                "Balanced buyer-seller growth",
                "Trust and safety mechanisms",
                "Efficient matching algorithms",
                "Geographic or vertical density"
            ],
            "d2c": [
                "Strong brand identity and storytelling",
                "Efficient digital marketing and CAC",
                "High repeat purchase rates",
                "Supply chain and fulfillment excellence",
                "Customer experience and community"
            ],
            "healthtech": [
                "Clinical validation and outcomes data",
                "Regulatory compliance and approvals",
                "Healthcare provider relationships",
                "Integration with existing systems",
                "Patient engagement and adherence"
            ],
            "consumer_subscriptions": [
                "Compelling content or service offering",
                "Low churn and high engagement",
                "Efficient conversion from free to paid",
                "Strong value proposition vs alternatives",
                "Effective retention and win-back strategies"
            ],
            "hardware": [
                "Product quality and reliability",
                "Efficient manufacturing and supply chain",
                "Strong distribution channels",
                "Software and service integration",
                "Cost optimization and scale"
            ],
            "services": [
                "Strong client relationships and reputation",
                "High utilization and project margins",
                "Talent acquisition and retention",
                "Consistent delivery quality",
                "Recurring revenue and long-term contracts"
            ]
        }
        return factors.get(industry, ["Industry-specific success factors"])
    
    def _get_common_challenges(self, industry: str) -> List[str]:
        """Get common challenges for an industry."""
        challenges = {
            "saas": [
                "High customer acquisition costs in competitive markets",
                "Long sales cycles for enterprise deals",
                "Product complexity and feature bloat",
                "Scaling customer success operations",
                "Differentiation in crowded markets"
            ],
            "fintech": [
                "Regulatory complexity and compliance costs",
                "Building trust with users",
                "High customer acquisition costs",
                "Fraud and security risks",
                "Integration with legacy systems"
            ],
            "marketplace": [
                "Chicken-and-egg problem of liquidity",
                "Balancing supply and demand",
                "Quality control and trust issues",
                "Take rate optimization",
                "Competition from vertical specialists"
            ],
            "d2c": [
                "Rising digital marketing costs",
                "Customer acquisition sustainability",
                "Supply chain and inventory management",
                "Brand differentiation",
                "Scaling beyond early adopters"
            ],
            "healthtech": [
                "Long regulatory approval timelines",
                "Complex healthcare sales cycles",
                "Reimbursement and payment challenges",
                "Integration with health systems",
                "Clinical evidence requirements"
            ],
            "consumer_subscriptions": [
                "High churn rates",
                "Content/service costs",
                "Competition from free alternatives",
                "Price sensitivity",
                "Engagement and retention"
            ],
            "hardware": [
                "High capital requirements",
                "Manufacturing and supply chain risks",
                "Long development cycles",
                "Lower margins and scalability",
                "Inventory management"
            ],
            "services": [
                "People dependency and scalability limits",
                "Utilization and capacity management",
                "Talent retention and recruitment",
                "Client concentration risk",
                "Project margin pressure"
            ]
        }
        return challenges.get(industry, ["Industry-specific challenges"])
    
    # =====================================================================
    # REPORTING METHODS
    # =====================================================================
    
    def generate_market_report(
        self, 
        industry: str, 
        stage: CompanyStage,
        company_metrics: Optional[Dict[str, float]] = None
    ) -> Dict[str, Any]:
        """
        Generate comprehensive market analysis report.
        
        Args:
            industry: Industry key
            stage: Company stage
            company_metrics: Optional company metrics for comparison
            
        Returns:
            Complete market analysis report
        """
        report = {
            "report_type": "Market Intelligence Report",
            "generated_by": "MarketAgent",
            "industry": self.get_industry_info(industry),
            "stage": stage.value,
            "benchmarks": self.get_industry_metrics(industry, stage).to_dict(),
            "valuation_context": {
                "typical_multiple": self.get_valuation_multiple(industry, stage),
                "typical_arr_range": self.get_typical_arr_range(industry, stage)
            },
            "industry_insights": self.get_industry_insights(industry),
            "market_sizing_template": self.get_market_sizing_template(industry)
        }
        
        if company_metrics:
            report["company_analysis"] = self.get_competitive_analysis(
                industry, stage, company_metrics
            )
        
        return report
    
    def export_benchmarks(self, format: str = "json") -> str:
        """
        Export all benchmarks in specified format.
        
        Args:
            format: Export format (json, dict)
            
        Returns:
            Formatted benchmark data
        """
        if format == "json":
            # Convert to serializable format
            export_data = {}
            for industry, data in self.benchmarks.items():
                export_data[industry] = {
                    "display_name": data["display_name"],
                    "description": data["description"],
                    "key_characteristics": data["key_characteristics"],
                    "industry_specific_metrics": data.get("industry_specific_metrics", {}),
                    "stages": {}
                }
                for stage, stage_data in data["stages"].items():
                    export_data[industry]["stages"][stage.value] = {
                        "metrics": stage_data["metrics"].to_dict(),
                        "valuation_multiple": stage_data.get("valuation_multiple", "N/A"),
                        "typical_arr_range": stage_data.get("typical_arr_range", "N/A")
                    }
            return json.dumps(export_data, indent=2)
        
        elif format == "dict":
            return self.benchmarks
        
        else:
            raise ValueError(f"Unsupported format: {format}")


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def create_market_agent() -> MarketAgent:
    """Factory function to create a MarketAgent instance."""
    return MarketAgent()


def get_quick_benchmark(industry: str, stage: str, metric: str) -> Optional[float]:
    """
    Quick utility to get a single benchmark value.
    
    Args:
        industry: Industry key
        stage: Stage string (e.g., 'series_a')
        metric: Metric name
        
    Returns:
        Benchmark value or None
    """
    agent = MarketAgent()
    try:
        stage_enum = CompanyStage(stage)
        metrics = agent.get_industry_metrics(industry, stage_enum)
        return getattr(metrics, metric, None)
    except (ValueError, AttributeError):
        return None


def compare_metrics_to_benchmarks(
    industry: str, 
    stage: str, 
    metrics: Dict[str, float]
) -> Dict[str, Any]:
    """
    Quick utility to compare metrics to benchmarks.
    
    Args:
        industry: Industry key
        stage: Stage string
        metrics: Company metrics dictionary
        
    Returns:
        Comparison results
    """
    agent = MarketAgent()
    stage_enum = CompanyStage(stage)
    return agent.compare_to_benchmark(industry, stage_enum, metrics)


# =============================================================================
# MODULE EXPORTS
# =============================================================================

__all__ = [
    'MarketAgent',
    'MarketMetrics',
    'CompanyStage',
    'MarketPosition',
    'INDUSTRY_BENCHMARKS',
    'create_market_agent',
    'get_quick_benchmark',
    'compare_metrics_to_benchmarks'
]


# Example usage
if __name__ == "__main__":
    # Create agent
    agent = create_market_agent()
    
    # Get available industries
    print("Available Industries:")
    for industry in agent.get_available_industries():
        info = agent.get_industry_info(industry)
        print(f"  - {info['display_name']}")
    
    # Example: Compare SaaS company metrics
    print("\n" + "="*60)
    print("Example: SaaS Series A Company Analysis")
    print("="*60)
    
    company_metrics = {
        "revenue_growth_mom": 15.0,
        "ltv_cac_ratio": 6.0,
        "churn_rate_monthly": 3.5,
        "gross_margin": 78.0,
        "net_revenue_retention": 108.0,
        "burn_multiple": 1.3
    }
    
    analysis = agent.get_competitive_analysis(
        industry="saas",
        stage=CompanyStage.SERIES_A,
        company_metrics=company_metrics
    )
    
    print(f"\nPosition: {analysis['positioning']['position']}")
    print(f"Description: {analysis['positioning']['position_description']}")
    print(f"\nStrengths:")
    for strength in analysis['positioning']['strengths']:
        print(f"  ✓ {strength}")
    print(f"\nAreas for Improvement:")
    for area in analysis['positioning']['improvement_areas']:
        print(f"  △ {area}")
    
    print("\n" + "="*60)
    print("Key Metrics Summary:")
    print("="*60)
    for metric, data in analysis['key_metrics_summary'].items():
        print(f"  {metric}: {data['value']} (benchmark: {data['benchmark']}, {data['status']})")
