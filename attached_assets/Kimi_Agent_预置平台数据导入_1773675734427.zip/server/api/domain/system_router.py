"""
System Router - Admin API Endpoints for System Management

This module provides admin-gated endpoints for system-level operations
including research data import functionality for benchmarks, decision patterns,
and simulation defaults.
"""

from typing import List, Optional, Dict, Any, Union
from datetime import datetime
from enum import Enum
import logging

from fastapi import APIRouter, Depends, HTTPException, status, Body
from pydantic import BaseModel, Field, validator, root_validator

# Configure logging
logger = logging.getLogger(__name__)

# =============================================================================
# Router Definition
# =============================================================================

router = APIRouter(
    prefix="/api/system",
    tags=["system"],
    responses={
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - Admin access required"},
        422: {"description": "Validation Error"},
        500: {"description": "Internal Server Error"},
    },
)


# =============================================================================
# Enums and Constants
# =============================================================================

class Industry(str, Enum):
    """Supported industry types for benchmarks."""
    TECHNOLOGY = "technology"
    HEALTHCARE = "healthcare"
    FINANCE = "finance"
    RETAIL = "retail"
    MANUFACTURING = "manufacturing"
    ENERGY = "energy"
    EDUCATION = "education"
    OTHER = "other"


class Stage(str, Enum):
    """Company growth stages for benchmarks."""
    SEED = "seed"
    SERIES_A = "series_a"
    SERIES_B = "series_b"
    SERIES_C = "series_c"
    GROWTH = "growth"
    ESTABLISHED = "established"


class DecisionType(str, Enum):
    """Types of decision patterns."""
    STRATEGIC = "strategic"
    OPERATIONAL = "operational"
    TACTICAL = "tactical"
    FINANCIAL = "financial"
    MARKETING = "marketing"
    PRODUCT = "product"


class ConfidenceLevel(str, Enum):
    """Confidence levels for data quality."""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


# =============================================================================
# Pydantic Models - Benchmarks
# =============================================================================

class BenchmarkInput(BaseModel):
    """
    Input model for a single benchmark record.
    
    Benchmarks represent industry-standard metrics used for comparison
    and analysis across different industries and company stages.
    """
    industry: Industry = Field(
        ...,
        description="Industry category for the benchmark"
    )
    stage: Stage = Field(
        ...,
        description="Company growth stage for the benchmark"
    )
    metric_name: str = Field(
        ...,
        min_length=1,
        max_length=100,
        description="Name of the metric (e.g., 'burn_rate', 'cac', 'ltv')"
    )
    metric_value: float = Field(
        ...,
        description="Numerical value of the metric"
    )
    unit: str = Field(
        ...,
        min_length=1,
        max_length=50,
        description="Unit of measurement (e.g., 'USD', '%', 'months')"
    )
    source: Optional[str] = Field(
        default=None,
        max_length=255,
        description="Source of the benchmark data"
    )
    year: Optional[int] = Field(
        default=None,
        ge=2000,
        le=2100,
        description="Year the data was collected"
    )
    confidence: Optional[ConfidenceLevel] = Field(
        default=ConfidenceLevel.MEDIUM,
        description="Confidence level of the data quality"
    )
    metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Additional metadata as key-value pairs"
    )

    @validator("metric_value")
    def validate_metric_value(cls, v):
        """Validate that metric value is a finite number."""
        if not isinstance(v, (int, float)):
            raise ValueError("metric_value must be a number")
        if v != v:  # Check for NaN
            raise ValueError("metric_value cannot be NaN")
        if v == float('inf') or v == float('-inf'):
            raise ValueError("metric_value must be finite")
        return v

    class Config:
        schema_extra = {
            "example": {
                "industry": "technology",
                "stage": "series_a",
                "metric_name": "burn_rate",
                "metric_value": 150000.0,
                "unit": "USD/month",
                "source": "Industry Report 2024",
                "year": 2024,
                "confidence": "high",
                "metadata": {"sample_size": 150, "region": "North America"}
            }
        }


# =============================================================================
# Pydantic Models - Decision Patterns
# =============================================================================

class DecisionPatternInput(BaseModel):
    """
    Input model for a single decision pattern record.
    
    Decision patterns represent common decision-making frameworks
    and their associated outcomes across different contexts.
    """
    pattern_name: str = Field(
        ...,
        min_length=1,
        max_length=100,
        description="Unique name identifier for the decision pattern"
    )
    decision_type: DecisionType = Field(
        ...,
        description="Category of decision"
    )
    description: str = Field(
        ...,
        min_length=10,
        max_length=2000,
        description="Detailed description of the decision pattern"
    )
    success_rate: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Success rate as decimal (0.0 to 1.0)"
    )
    avg_outcome_value: Optional[float] = Field(
        default=None,
        description="Average outcome value in currency units"
    )
    factors: Optional[List[str]] = Field(
        default=None,
        description="List of key factors influencing this decision"
    )
    industry: Optional[Industry] = Field(
        default=None,
        description="Primary industry applicability"
    )
    applicable_stages: Optional[List[Stage]] = Field(
        default=None,
        description="Company stages where this pattern applies"
    )
    confidence: Optional[ConfidenceLevel] = Field(
        default=ConfidenceLevel.MEDIUM,
        description="Confidence level based on data quality"
    )
    source: Optional[str] = Field(
        default=None,
        max_length=255,
        description="Source of the pattern data"
    )
    metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Additional metadata as key-value pairs"
    )

    @validator("factors")
    def validate_factors(cls, v):
        """Validate that factors list is not empty if provided."""
        if v is not None and len(v) == 0:
            raise ValueError("factors list cannot be empty if provided")
        return v

    @validator("applicable_stages")
    def validate_stages(cls, v):
        """Validate that stages list is not empty if provided."""
        if v is not None and len(v) == 0:
            raise ValueError("applicable_stages list cannot be empty if provided")
        return v

    class Config:
        schema_extra = {
            "example": {
                "pattern_name": "market_expansion",
                "decision_type": "strategic",
                "description": "Expanding into new geographic markets based on demand analysis",
                "success_rate": 0.65,
                "avg_outcome_value": 2500000.0,
                "factors": ["market_size", "competition", "regulatory_environment"],
                "industry": "technology",
                "applicable_stages": ["series_b", "series_c", "growth"],
                "confidence": "high",
                "source": "McKinsey Study 2023",
                "metadata": {"study_size": 500, "timeframe": "5 years"}
            }
        }


# =============================================================================
# Pydantic Models - Simulation Defaults
# =============================================================================

class SimulationDefaultInput(BaseModel):
    """
    Input model for simulation default parameters.
    
    These defaults are used to initialize simulation scenarios
    with realistic starting values.
    """
    scenario_type: str = Field(
        ...,
        min_length=1,
        max_length=50,
        description="Type of simulation scenario"
    )
    parameter_name: str = Field(
        ...,
        min_length=1,
        max_length=100,
        description="Name of the simulation parameter"
    )
    default_value: Union[float, int, str, bool] = Field(
        ...,
        description="Default value for the parameter"
    )
    value_type: str = Field(
        ...,
        regex="^(float|int|string|boolean)$",
        description="Data type of the default value"
    )
    min_value: Optional[float] = Field(
        default=None,
        description="Minimum allowed value (for numeric types)"
    )
    max_value: Optional[float] = Field(
        default=None,
        description="Maximum allowed value (for numeric types)"
    )
    description: Optional[str] = Field(
        default=None,
        max_length=500,
        description="Description of the parameter"
    )
    category: Optional[str] = Field(
        default=None,
        max_length=50,
        description="Parameter category for grouping"
    )

    @root_validator(pre=True)
    def validate_value_consistency(cls, values):
        """Validate that default_value matches value_type."""
        value = values.get("default_value")
        value_type = values.get("value_type")
        
        if value is not None and value_type is not None:
            type_map = {
                "float": (int, float),
                "int": int,
                "string": str,
                "boolean": bool
            }
            
            expected_type = type_map.get(value_type)
            if expected_type:
                if value_type == "float":
                    if not isinstance(value, (int, float)):
                        raise ValueError(f"default_value must be numeric for type 'float'")
                elif value_type == "int":
                    if not isinstance(value, int) or isinstance(value, bool):
                        raise ValueError(f"default_value must be integer for type 'int'")
                elif not isinstance(value, expected_type):
                    raise ValueError(f"default_value must be {value_type} type")
        
        return values

    @root_validator
    def validate_range(cls, values):
        """Validate that min_value is less than max_value."""
        min_val = values.get("min_value")
        max_val = values.get("max_value")
        
        if min_val is not None and max_val is not None:
            if min_val >= max_val:
                raise ValueError("min_value must be less than max_value")
        
        return values

    class Config:
        schema_extra = {
            "example": {
                "scenario_type": "market_entry",
                "parameter_name": "initial_investment",
                "default_value": 500000.0,
                "value_type": "float",
                "min_value": 100000.0,
                "max_value": 5000000.0,
                "description": "Initial capital investment for market entry",
                "category": "financial"
            }
        }


# =============================================================================
# Request/Response Models
# =============================================================================

class ImportResearchDataRequest(BaseModel):
    """
    Request model for importing research data.
    
    This model defines the structure for bulk importing benchmarks,
    decision patterns, and simulation defaults into the system.
    """
    benchmarks: List[BenchmarkInput] = Field(
        ...,
        min_items=1,
        description="Array of benchmark records to import"
    )
    decision_patterns: List[DecisionPatternInput] = Field(
        ...,
        min_items=1,
        description="Array of decision pattern records to import"
    )
    simulation_defaults: Optional[List[SimulationDefaultInput]] = Field(
        default=None,
        description="Optional array of simulation default parameters"
    )

    @validator("benchmarks")
    def validate_benchmarks(cls, v):
        """Validate benchmarks array."""
        if len(v) > 10000:
            raise ValueError("Maximum 10,000 benchmarks allowed per request")
        return v

    @validator("decision_patterns")
    def validate_patterns(cls, v):
        """Validate decision patterns array."""
        if len(v) > 5000:
            raise ValueError("Maximum 5,000 decision patterns allowed per request")
        return v

    @validator("simulation_defaults")
    def validate_defaults(cls, v):
        """Validate simulation defaults array."""
        if v is not None and len(v) > 2000:
            raise ValueError("Maximum 2,000 simulation defaults allowed per request")
        return v

    class Config:
        schema_extra = {
            "example": {
                "benchmarks": [
                    {
                        "industry": "technology",
                        "stage": "series_a",
                        "metric_name": "burn_rate",
                        "metric_value": 150000.0,
                        "unit": "USD/month",
                        "source": "Industry Report 2024",
                        "year": 2024,
                        "confidence": "high"
                    }
                ],
                "decision_patterns": [
                    {
                        "pattern_name": "market_expansion",
                        "decision_type": "strategic",
                        "description": "Expanding into new geographic markets",
                        "success_rate": 0.65,
                        "industry": "technology",
                        "confidence": "high"
                    }
                ],
                "simulation_defaults": [
                    {
                        "scenario_type": "market_entry",
                        "parameter_name": "initial_investment",
                        "default_value": 500000.0,
                        "value_type": "float"
                    }
                ]
            }
        }


class ImportResearchDataResponse(BaseModel):
    """
    Response model for research data import operation.
    
    Provides detailed counts of inserted and updated records
    along with any errors encountered during the import process.
    """
    success: bool = Field(
        ...,
        description="Whether the import operation completed successfully"
    )
    benchmarks_inserted: int = Field(
        default=0,
        ge=0,
        description="Number of new benchmark records inserted"
    )
    benchmarks_updated: int = Field(
        default=0,
        ge=0,
        description="Number of existing benchmark records updated"
    )
    patterns_inserted: int = Field(
        default=0,
        ge=0,
        description="Number of new decision pattern records inserted"
    )
    patterns_updated: int = Field(
        default=0,
        ge=0,
        description="Number of existing decision pattern records updated"
    )
    defaults_inserted: int = Field(
        default=0,
        ge=0,
        description="Number of new simulation default records inserted"
    )
    defaults_updated: int = Field(
        default=0,
        ge=0,
        description="Number of existing simulation default records updated"
    )
    errors: List[Dict[str, Any]] = Field(
        default_factory=list,
        description="List of errors encountered during import"
    )
    processing_time_ms: Optional[int] = Field(
        default=None,
        description="Total processing time in milliseconds"
    )

    class Config:
        schema_extra = {
            "example": {
                "success": True,
                "benchmarks_inserted": 10,
                "benchmarks_updated": 5,
                "patterns_inserted": 20,
                "patterns_updated": 3,
                "defaults_inserted": 5,
                "defaults_updated": 2,
                "errors": [],
                "processing_time_ms": 1250
            }
        }


class ErrorDetail(BaseModel):
    """Detailed error information for import failures."""
    record_type: str = Field(..., description="Type of record that failed")
    index: int = Field(..., description="Index of the failed record in the input array")
    field: Optional[str] = Field(None, description="Field that caused the error")
    message: str = Field(..., description="Error message")
    value: Optional[Any] = Field(None, description="Value that caused the error")


# =============================================================================
# Admin Authentication Dependency
# =============================================================================

async def require_admin_auth() -> Dict[str, Any]:
    """
    Dependency to verify admin authentication.
    
    This dependency checks if the current user has admin privileges.
    In a production environment, this would validate JWT tokens,
    session cookies, or API keys.
    
    Returns:
        Dict containing user information if admin
        
    Raises:
        HTTPException: 403 if user is not an admin
        HTTPException: 401 if authentication is missing/invalid
    """
    # TODO: Implement actual authentication logic
    # This is a placeholder that should be replaced with:
    # - JWT token validation
    # - Session cookie verification
    # - API key validation
    # - Database lookup for user permissions
    
    # Placeholder implementation - always returns admin for development
    # In production, this should validate the request
    return {
        "user_id": "admin_user",
        "role": "admin",
        "permissions": ["import_research_data", "manage_system"]
    }


# =============================================================================
# Database Service (Placeholder - Replace with actual implementation)
# =============================================================================

class ResearchDataService:
    """
    Service class for research data database operations.
    
    This is a placeholder implementation. In production, replace with
    actual database service using SQLAlchemy, asyncpg, or similar.
    """
    
    @staticmethod
    async def upsert_benchmarks(
        benchmarks: List[BenchmarkInput]
    ) -> Dict[str, int]:
        """
        Upsert benchmark records into the database.
        
        Matching is done on industry + stage + metric_name.
        
        Args:
            benchmarks: List of benchmark records to upsert
            
        Returns:
            Dict with 'inserted' and 'updated' counts
        """
        # TODO: Implement actual database upsert logic
        # Example SQL: INSERT ... ON CONFLICT (industry, stage, metric_name) DO UPDATE ...
        
        inserted = 0
        updated = 0
        
        for benchmark in benchmarks:
            # Simulate upsert logic
            # Check if record exists based on industry+stage+metric_name
            exists = await ResearchDataService._check_benchmark_exists(
                benchmark.industry, benchmark.stage, benchmark.metric_name
            )
            
            if exists:
                updated += 1
                # await db.execute(update_query, ...)
            else:
                inserted += 1
                # await db.execute(insert_query, ...)
        
        return {"inserted": inserted, "updated": updated}
    
    @staticmethod
    async def upsert_decision_patterns(
        patterns: List[DecisionPatternInput]
    ) -> Dict[str, int]:
        """
        Upsert decision pattern records into the database.
        
        Matching is done on pattern_name.
        
        Args:
            patterns: List of decision pattern records to upsert
            
        Returns:
            Dict with 'inserted' and 'updated' counts
        """
        inserted = 0
        updated = 0
        
        for pattern in patterns:
            exists = await ResearchDataService._check_pattern_exists(
                pattern.pattern_name
            )
            
            if exists:
                updated += 1
            else:
                inserted += 1
        
        return {"inserted": inserted, "updated": updated}
    
    @staticmethod
    async def upsert_simulation_defaults(
        defaults: List[SimulationDefaultInput]
    ) -> Dict[str, int]:
        """
        Upsert simulation default records into the database.
        
        Matching is done on scenario_type + parameter_name.
        
        Args:
            defaults: List of simulation default records to upsert
            
        Returns:
            Dict with 'inserted' and 'updated' counts
        """
        inserted = 0
        updated = 0
        
        for default in defaults:
            exists = await ResearchDataService._check_default_exists(
                default.scenario_type, default.parameter_name
            )
            
            if exists:
                updated += 1
            else:
                inserted += 1
        
        return {"inserted": inserted, "updated": updated}
    
    # Placeholder methods for existence checks
    @staticmethod
    async def _check_benchmark_exists(
        industry: Industry, stage: Stage, metric_name: str
    ) -> bool:
        """Check if a benchmark record exists."""
        # TODO: Implement actual database query
        return False  # Placeholder
    
    @staticmethod
    async def _check_pattern_exists(pattern_name: str) -> bool:
        """Check if a decision pattern exists."""
        # TODO: Implement actual database query
        return False  # Placeholder
    
    @staticmethod
    async def _check_default_exists(
        scenario_type: str, parameter_name: str
    ) -> bool:
        """Check if a simulation default exists."""
        # TODO: Implement actual database query
        return False  # Placeholder


# =============================================================================
# API Endpoints
# =============================================================================

@router.post(
    "/import-research-data",
    response_model=ImportResearchDataResponse,
    status_code=status.HTTP_200_OK,
    summary="Import research data (Admin only)",
    description="""
    Import research data including benchmarks, decision patterns, and simulation defaults.
    
    ## Authentication
    This endpoint requires admin authentication. Non-admin users will receive a 403 response.
    
    ## Upsert Behavior
    - **Benchmarks**: Matched on industry + stage + metric_name
    - **Decision Patterns**: Matched on pattern_name
    - **Simulation Defaults**: Matched on scenario_type + parameter_name
    
    ## Limits
    - Maximum 10,000 benchmarks per request
    - Maximum 5,000 decision patterns per request
    - Maximum 2,000 simulation defaults per request
    
    ## Response
    Returns counts of inserted and updated records for each data type.
    Errors are collected and returned without failing the entire operation.
    """,
    response_description="Import operation results with counts and errors",
    responses={
        200: {
            "description": "Import completed successfully",
            "model": ImportResearchDataResponse
        },
        400: {
            "description": "Validation error in request data",
            "content": {
                "application/json": {
                    "example": {
                        "detail": [
                            {
                                "loc": ["body", "benchmarks", 0, "metric_value"],
                                "msg": "metric_value must be a number",
                                "type": "value_error"
                            }
                        ]
                    }
                }
            }
        },
        401: {
            "description": "Authentication required",
            "content": {
                "application/json": {
                    "example": {"detail": "Authentication required"}
                }
            }
        },
        403: {
            "description": "Admin access required",
            "content": {
                "application/json": {
                    "example": {"detail": "Admin access required"}
                }
            }
        },
        422: {
            "description": "Request validation failed"
        },
        500: {
            "description": "Internal server error",
            "content": {
                "application/json": {
                    "example": {"detail": "Internal server error during import"}
                }
            }
        }
    }
)
async def import_research_data(
    request: ImportResearchDataRequest = Body(
        ...,
        description="Research data to import",
        example={
            "benchmarks": [
                {
                    "industry": "technology",
                    "stage": "series_a",
                    "metric_name": "burn_rate",
                    "metric_value": 150000.0,
                    "unit": "USD/month",
                    "source": "Industry Report 2024",
                    "year": 2024,
                    "confidence": "high"
                }
            ],
            "decision_patterns": [
                {
                    "pattern_name": "market_expansion",
                    "decision_type": "strategic",
                    "description": "Expanding into new geographic markets based on demand analysis",
                    "success_rate": 0.65,
                    "industry": "technology",
                    "confidence": "high"
                }
            ],
            "simulation_defaults": [
                {
                    "scenario_type": "market_entry",
                    "parameter_name": "initial_investment",
                    "default_value": 500000.0,
                    "value_type": "float"
                }
            ]
        }
    ),
    admin_user: Dict[str, Any] = Depends(require_admin_auth)
) -> ImportResearchDataResponse:
    """
    Import research data into the system.
    
    This admin-only endpoint allows bulk import of:
    - Industry benchmarks for comparison
    - Decision patterns for analysis
    - Simulation default parameters
    
    Args:
        request: ImportResearchDataRequest containing data to import
        admin_user: Authenticated admin user (from dependency)
        
    Returns:
        ImportResearchDataResponse with operation results
        
    Raises:
        HTTPException: If authentication fails or server error occurs
    """
    import time
    start_time = time.time()
    
    logger.info(
        f"Admin user {admin_user.get('user_id')} initiating research data import: "
        f"{len(request.benchmarks)} benchmarks, "
        f"{len(request.decision_patterns)} patterns, "
        f"{len(request.simulation_defaults or [])} defaults"
    )
    
    errors: List[Dict[str, Any]] = []
    
    try:
        # Process benchmarks
        try:
            benchmark_result = await ResearchDataService.upsert_benchmarks(
                request.benchmarks
            )
        except Exception as e:
            logger.error(f"Error upserting benchmarks: {str(e)}")
            errors.append({
                "record_type": "benchmark",
                "message": f"Failed to process benchmarks: {str(e)}"
            })
            benchmark_result = {"inserted": 0, "updated": 0}
        
        # Process decision patterns
        try:
            pattern_result = await ResearchDataService.upsert_decision_patterns(
                request.decision_patterns
            )
        except Exception as e:
            logger.error(f"Error upserting decision patterns: {str(e)}")
            errors.append({
                "record_type": "decision_pattern",
                "message": f"Failed to process decision patterns: {str(e)}"
            })
            pattern_result = {"inserted": 0, "updated": 0}
        
        # Process simulation defaults (optional)
        defaults_result = {"inserted": 0, "updated": 0}
        if request.simulation_defaults:
            try:
                defaults_result = await ResearchDataService.upsert_simulation_defaults(
                    request.simulation_defaults
                )
            except Exception as e:
                logger.error(f"Error upserting simulation defaults: {str(e)}")
                errors.append({
                    "record_type": "simulation_default",
                    "message": f"Failed to process simulation defaults: {str(e)}"
                })
        
        processing_time = int((time.time() - start_time) * 1000)
        
        success = len(errors) == 0 or (
            benchmark_result["inserted"] + benchmark_result["updated"] > 0 or
            pattern_result["inserted"] + pattern_result["updated"] > 0
        )
        
        logger.info(
            f"Research data import completed in {processing_time}ms: "
            f"benchmarks({benchmark_result['inserted']}/{benchmark_result['updated']}), "
            f"patterns({pattern_result['inserted']}/{pattern_result['updated']}), "
            f"defaults({defaults_result['inserted']}/{defaults_result['updated']})"
        )
        
        return ImportResearchDataResponse(
            success=success,
            benchmarks_inserted=benchmark_result["inserted"],
            benchmarks_updated=benchmark_result["updated"],
            patterns_inserted=pattern_result["inserted"],
            patterns_updated=pattern_result["updated"],
            defaults_inserted=defaults_result["inserted"],
            defaults_updated=defaults_result["updated"],
            errors=errors,
            processing_time_ms=processing_time
        )
        
    except Exception as e:
        logger.exception("Unexpected error during research data import")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal server error during import: {str(e)}"
        )


# =============================================================================
# Health Check Endpoint
# =============================================================================

@router.get(
    "/health",
    response_model=Dict[str, str],
    summary="System health check",
    description="Check if the system API is operational."
)
async def health_check() -> Dict[str, str]:
    """
    Health check endpoint for monitoring.
    
    Returns:
        Dict with status message
    """
    return {"status": "healthy", "service": "system-api"}


# =============================================================================
# Export router for use in main application
# =============================================================================

__all__ = ["router"]
