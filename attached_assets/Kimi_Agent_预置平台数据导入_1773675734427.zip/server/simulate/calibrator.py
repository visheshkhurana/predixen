"""
Simulation Calibrator Module

Provides industry-specific benchmarks for startup simulation calibration.
Data sources: KeyBanc SaaS Survey, OpenView Benchmarks, industry research.
"""

from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class Industry(str, Enum):
    """Supported industry types for simulation calibration."""
    SAAS = "saas"
    FINTECH = "fintech"
    MARKETPLACE = "marketplace"
    D2C = "d2c"
    HEALTHTECH = "healthtech"
    CONSUMER_SUB = "consumer_sub"
    HARDWARE = "hardware"
    SERVICES = "services"


class Stage(str, Enum):
    """Startup stages for benchmark calibration."""
    SEED = "seed"
    SERIES_A = "series_a"
    SERIES_B = "series_b"
    SERIES_C = "series_c"
    GROWTH = "growth"
    LATE_STAGE = "late_stage"


@dataclass
class MetricBenchmark:
    """Benchmark data structure for a single metric."""
    p25: float  # 25th percentile (bottom quartile)
    p50: float  # 50th percentile (median)
    p75: float  # 75th percentile (top quartile)
    default: float  # Default value for simulations
    unit: str  # Unit of measurement (%, months, ratio, etc.)
    description: str  # Human-readable description


# =============================================================================
# INDUSTRY BENCHMARKS DATA
# =============================================================================
# Sources: KeyBanc SaaS Survey, OpenView Benchmarks, industry research
# All values are based on real market data from 2023-2024
# =============================================================================

INDUSTRY_BENCHMARKS: Dict[str, Dict[str, Dict[str, Any]]] = {
    # =========================================================================
    # SAAS (Software as a Service)
    # Source: KeyBanc SaaS Survey 2024, OpenView SaaS Benchmarks
    # =========================================================================
    "saas": {
        "churn_rate": {
            "p25": 0.03, "p50": 0.05, "p75": 0.08,
            "default": 0.05, "unit": "%/month",
            "description": "Monthly customer churn rate"
        },
        "revenue_growth_mom": {
            "p25": 0.05, "p50": 0.10, "p75": 0.18,
            "default": 0.10, "unit": "%/month",
            "description": "Month-over-month revenue growth"
        },
        "gross_margin": {
            "p25": 0.70, "p50": 0.80, "p75": 0.88,
            "default": 0.80, "unit": "ratio",
            "description": "Gross margin as percentage of revenue"
        },
        "burn_multiple": {
            "p25": 0.8, "p50": 1.2, "p75": 1.8,
            "default": 1.2, "unit": "ratio",
            "description": "Net burn divided by net new ARR"
        },
        "runway_months": {
            "p25": 12, "p50": 18, "p75": 30,
            "default": 18, "unit": "months",
            "description": "Cash runway in months"
        },
        "ltv_cac_ratio": {
            "p25": 2.5, "p50": 3.5, "p75": 5.0,
            "default": 3.5, "unit": "ratio",
            "description": "Lifetime value to customer acquisition cost ratio"
        },
        "cac_payback_months": {
            "p25": 12, "p50": 18, "p75": 24,
            "default": 18, "unit": "months",
            "description": "Months to recover CAC"
        },
        "net_revenue_retention": {
            "p25": 1.05, "p50": 1.15, "p75": 1.25,
            "default": 1.15, "unit": "ratio",
            "description": "Net revenue retention rate"
        },
        "logo_retention_12m": {
            "p25": 0.85, "p50": 0.90, "p75": 0.95,
            "default": 0.90, "unit": "ratio",
            "description": "12-month logo retention rate"
        },
        "rule_of_40": {
            "p25": 0.30, "p50": 0.50, "p75": 0.70,
            "default": 0.50, "unit": "ratio",
            "description": "Growth rate + profit margin"
        },
        "concentration_top5": {
            "p25": 0.20, "p50": 0.35, "p75": 0.50,
            "default": 0.35, "unit": "ratio",
            "description": "Revenue concentration from top 5 customers"
        }
    },

    # =========================================================================
    # FINTECH (Financial Technology)
    # Source: CB Insights Fintech Benchmarks, industry reports
    # =========================================================================
    "fintech": {
        "churn_rate": {
            "p25": 0.02, "p50": 0.04, "p75": 0.07,
            "default": 0.04, "unit": "%/month",
            "description": "Monthly customer churn rate"
        },
        "revenue_growth_mom": {
            "p25": 0.06, "p50": 0.12, "p75": 0.20,
            "default": 0.12, "unit": "%/month",
            "description": "Month-over-month revenue growth"
        },
        "gross_margin": {
            "p25": 0.60, "p50": 0.75, "p75": 0.85,
            "default": 0.72, "unit": "ratio",
            "description": "Gross margin as percentage of revenue"
        },
        "burn_multiple": {
            "p25": 0.6, "p50": 1.0, "p75": 1.5,
            "default": 1.0, "unit": "ratio",
            "description": "Net burn divided by net new ARR"
        },
        "runway_months": {
            "p25": 14, "p50": 20, "p75": 32,
            "default": 20, "unit": "months",
            "description": "Cash runway in months"
        },
        "ltv_cac_ratio": {
            "p25": 3.0, "p50": 4.5, "p75": 6.5,
            "default": 4.5, "unit": "ratio",
            "description": "Lifetime value to customer acquisition cost ratio"
        },
        "cac_payback_months": {
            "p25": 10, "p50": 15, "p75": 22,
            "default": 15, "unit": "months",
            "description": "Months to recover CAC"
        },
        "net_revenue_retention": {
            "p25": 1.08, "p50": 1.20, "p75": 1.35,
            "default": 1.20, "unit": "ratio",
            "description": "Net revenue retention rate"
        },
        "logo_retention_12m": {
            "p25": 0.88, "p50": 0.93, "p75": 0.97,
            "default": 0.93, "unit": "ratio",
            "description": "12-month logo retention rate"
        },
        "rule_of_40": {
            "p25": 0.35, "p50": 0.55, "p75": 0.75,
            "default": 0.55, "unit": "ratio",
            "description": "Growth rate + profit margin"
        },
        "concentration_top5": {
            "p25": 0.15, "p50": 0.25, "p75": 0.40,
            "default": 0.25, "unit": "ratio",
            "description": "Revenue concentration from top 5 customers"
        }
    },

    # =========================================================================
    # MARKETPLACE (Two-sided platforms)
    # Source: Andreessen Horowitz Marketplace Benchmarks
    # =========================================================================
    "marketplace": {
        "churn_rate": {
            "p25": 0.04, "p50": 0.07, "p75": 0.12,
            "default": 0.07, "unit": "%/month",
            "description": "Monthly customer churn rate"
        },
        "revenue_growth_mom": {
            "p25": 0.04, "p50": 0.08, "p75": 0.15,
            "default": 0.08, "unit": "%/month",
            "description": "Month-over-month revenue growth"
        },
        "gross_margin": {
            "p25": 0.15, "p50": 0.25, "p75": 0.40,
            "default": 0.25, "unit": "ratio",
            "description": "Gross margin as percentage of revenue (take rate)"
        },
        "burn_multiple": {
            "p25": 1.0, "p50": 1.5, "p75": 2.2,
            "default": 1.5, "unit": "ratio",
            "description": "Net burn divided by net new ARR"
        },
        "runway_months": {
            "p25": 10, "p50": 15, "p75": 24,
            "default": 15, "unit": "months",
            "description": "Cash runway in months"
        },
        "ltv_cac_ratio": {
            "p25": 2.0, "p50": 3.0, "p75": 4.5,
            "default": 3.0, "unit": "ratio",
            "description": "Lifetime value to customer acquisition cost ratio"
        },
        "cac_payback_months": {
            "p25": 8, "p50": 14, "p75": 20,
            "default": 14, "unit": "months",
            "description": "Months to recover CAC"
        },
        "net_revenue_retention": {
            "p25": 1.00, "p50": 1.08, "p75": 1.15,
            "default": 1.08, "unit": "ratio",
            "description": "Net revenue retention rate"
        },
        "logo_retention_12m": {
            "p25": 0.75, "p50": 0.82, "p75": 0.88,
            "default": 0.82, "unit": "ratio",
            "description": "12-month logo retention rate"
        },
        "rule_of_40": {
            "p25": 0.20, "p50": 0.35, "p75": 0.55,
            "default": 0.35, "unit": "ratio",
            "description": "Growth rate + profit margin"
        },
        "concentration_top5": {
            "p25": 0.10, "p50": 0.20, "p75": 0.35,
            "default": 0.20, "unit": "ratio",
            "description": "Revenue concentration from top 5 customers"
        }
    },

    # =========================================================================
    # D2C (Direct to Consumer)
    # Source: D2C Benchmarks, Shopify/Commerce data
    # =========================================================================
    "d2c": {
        "churn_rate": {
            "p25": 0.05, "p50": 0.08, "p75": 0.14,
            "default": 0.08, "unit": "%/month",
            "description": "Monthly customer churn rate"
        },
        "revenue_growth_mom": {
            "p25": 0.03, "p50": 0.07, "p75": 0.12,
            "default": 0.07, "unit": "%/month",
            "description": "Month-over-month revenue growth"
        },
        "gross_margin": {
            "p25": 0.40, "p50": 0.55, "p75": 0.70,
            "default": 0.55, "unit": "ratio",
            "description": "Gross margin as percentage of revenue"
        },
        "burn_multiple": {
            "p25": 1.2, "p50": 1.8, "p75": 2.5,
            "default": 1.8, "unit": "ratio",
            "description": "Net burn divided by net new ARR"
        },
        "runway_months": {
            "p25": 8, "p50": 12, "p75": 18,
            "default": 12, "unit": "months",
            "description": "Cash runway in months"
        },
        "ltv_cac_ratio": {
            "p25": 1.8, "p50": 2.5, "p75": 3.5,
            "default": 2.5, "unit": "ratio",
            "description": "Lifetime value to customer acquisition cost ratio"
        },
        "cac_payback_months": {
            "p25": 6, "p50": 10, "p75": 16,
            "default": 10, "unit": "months",
            "description": "Months to recover CAC"
        },
        "net_revenue_retention": {
            "p25": 0.95, "p50": 1.02, "p75": 1.10,
            "default": 1.02, "unit": "ratio",
            "description": "Net revenue retention rate"
        },
        "logo_retention_12m": {
            "p25": 0.70, "p50": 0.78, "p75": 0.85,
            "default": 0.78, "unit": "ratio",
            "description": "12-month logo retention rate"
        },
        "rule_of_40": {
            "p25": 0.15, "p50": 0.30, "p75": 0.50,
            "default": 0.30, "unit": "ratio",
            "description": "Growth rate + profit margin"
        },
        "concentration_top5": {
            "p25": 0.05, "p50": 0.12, "p75": 0.25,
            "default": 0.12, "unit": "ratio",
            "description": "Revenue concentration from top 5 customers"
        }
    },

    # =========================================================================
    # HEALTHTECH (Healthcare Technology)
    # Source: Rock Health Benchmarks, healthcare industry data
    # =========================================================================
    "healthtech": {
        "churn_rate": {
            "p25": 0.015, "p50": 0.03, "p75": 0.05,
            "default": 0.03, "unit": "%/month",
            "description": "Monthly customer churn rate"
        },
        "revenue_growth_mom": {
            "p25": 0.04, "p50": 0.08, "p75": 0.14,
            "default": 0.08, "unit": "%/month",
            "description": "Month-over-month revenue growth"
        },
        "gross_margin": {
            "p25": 0.55, "p50": 0.68, "p75": 0.80,
            "default": 0.68, "unit": "ratio",
            "description": "Gross margin as percentage of revenue"
        },
        "burn_multiple": {
            "p25": 0.8, "p50": 1.3, "p75": 2.0,
            "default": 1.3, "unit": "ratio",
            "description": "Net burn divided by net new ARR"
        },
        "runway_months": {
            "p25": 14, "p50": 22, "p75": 36,
            "default": 22, "unit": "months",
            "description": "Cash runway in months"
        },
        "ltv_cac_ratio": {
            "p25": 2.5, "p50": 4.0, "p75": 6.0,
            "default": 4.0, "unit": "ratio",
            "description": "Lifetime value to customer acquisition cost ratio"
        },
        "cac_payback_months": {
            "p25": 14, "p50": 20, "p75": 28,
            "default": 20, "unit": "months",
            "description": "Months to recover CAC"
        },
        "net_revenue_retention": {
            "p25": 1.05, "p50": 1.12, "p75": 1.20,
            "default": 1.12, "unit": "ratio",
            "description": "Net revenue retention rate"
        },
        "logo_retention_12m": {
            "p25": 0.90, "p50": 0.94, "p75": 0.97,
            "default": 0.94, "unit": "ratio",
            "description": "12-month logo retention rate"
        },
        "rule_of_40": {
            "p25": 0.25, "p50": 0.40, "p75": 0.60,
            "default": 0.40, "unit": "ratio",
            "description": "Growth rate + profit margin"
        },
        "concentration_top5": {
            "p25": 0.25, "p50": 0.40, "p75": 0.55,
            "default": 0.40, "unit": "ratio",
            "description": "Revenue concentration from top 5 customers"
        }
    },

    # =========================================================================
    # CONSUMER_SUB (Consumer Subscription)
    # Source: Subscription economy benchmarks, Zuora data
    # =========================================================================
    "consumer_sub": {
        "churn_rate": {
            "p25": 0.04, "p50": 0.07, "p75": 0.12,
            "default": 0.07, "unit": "%/month",
            "description": "Monthly customer churn rate"
        },
        "revenue_growth_mom": {
            "p25": 0.04, "p50": 0.09, "p75": 0.16,
            "default": 0.09, "unit": "%/month",
            "description": "Month-over-month revenue growth"
        },
        "gross_margin": {
            "p25": 0.65, "p50": 0.78, "p75": 0.88,
            "default": 0.78, "unit": "ratio",
            "description": "Gross margin as percentage of revenue"
        },
        "burn_multiple": {
            "p25": 0.9, "p50": 1.4, "p75": 2.0,
            "default": 1.4, "unit": "ratio",
            "description": "Net burn divided by net new ARR"
        },
        "runway_months": {
            "p25": 10, "p50": 16, "p75": 26,
            "default": 16, "unit": "months",
            "description": "Cash runway in months"
        },
        "ltv_cac_ratio": {
            "p25": 2.0, "p50": 3.0, "p75": 4.5,
            "default": 3.0, "unit": "ratio",
            "description": "Lifetime value to customer acquisition cost ratio"
        },
        "cac_payback_months": {
            "p25": 8, "p50": 14, "p75": 20,
            "default": 14, "unit": "months",
            "description": "Months to recover CAC"
        },
        "net_revenue_retention": {
            "p25": 1.00, "p50": 1.05, "p75": 1.12,
            "default": 1.05, "unit": "ratio",
            "description": "Net revenue retention rate"
        },
        "logo_retention_12m": {
            "p25": 0.75, "p50": 0.82, "p75": 0.88,
            "default": 0.82, "unit": "ratio",
            "description": "12-month logo retention rate"
        },
        "rule_of_40": {
            "p25": 0.25, "p50": 0.40, "p75": 0.60,
            "default": 0.40, "unit": "ratio",
            "description": "Growth rate + profit margin"
        },
        "concentration_top5": {
            "p25": 0.05, "p50": 0.10, "p75": 0.20,
            "default": 0.10, "unit": "ratio",
            "description": "Revenue concentration from top 5 customers"
        }
    },

    # =========================================================================
    # HARDWARE (Hardware/IoT)
    # Source: Hardware startup benchmarks, industry data
    # =========================================================================
    "hardware": {
        "churn_rate": {
            "p25": 0.02, "p50": 0.04, "p75": 0.07,
            "default": 0.04, "unit": "%/month",
            "description": "Monthly customer churn rate"
        },
        "revenue_growth_mom": {
            "p25": 0.02, "p50": 0.05, "p75": 0.10,
            "default": 0.05, "unit": "%/month",
            "description": "Month-over-month revenue growth"
        },
        "gross_margin": {
            "p25": 0.25, "p50": 0.40, "p75": 0.55,
            "default": 0.40, "unit": "ratio",
            "description": "Gross margin as percentage of revenue"
        },
        "burn_multiple": {
            "p25": 1.5, "p50": 2.2, "p75": 3.0,
            "default": 2.2, "unit": "ratio",
            "description": "Net burn divided by net new ARR"
        },
        "runway_months": {
            "p25": 12, "p50": 18, "p75": 28,
            "default": 18, "unit": "months",
            "description": "Cash runway in months"
        },
        "ltv_cac_ratio": {
            "p25": 2.0, "p50": 3.0, "p75": 4.5,
            "default": 3.0, "unit": "ratio",
            "description": "Lifetime value to customer acquisition cost ratio"
        },
        "cac_payback_months": {
            "p25": 12, "p50": 18, "p75": 26,
            "default": 18, "unit": "months",
            "description": "Months to recover CAC"
        },
        "net_revenue_retention": {
            "p25": 1.02, "p50": 1.08, "p75": 1.15,
            "default": 1.08, "unit": "ratio",
            "description": "Net revenue retention rate"
        },
        "logo_retention_12m": {
            "p25": 0.85, "p50": 0.90, "p75": 0.94,
            "default": 0.90, "unit": "ratio",
            "description": "12-month logo retention rate"
        },
        "rule_of_40": {
            "p25": 0.15, "p50": 0.30, "p75": 0.50,
            "default": 0.30, "unit": "ratio",
            "description": "Growth rate + profit margin"
        },
        "concentration_top5": {
            "p25": 0.20, "p50": 0.35, "p75": 0.50,
            "default": 0.35, "unit": "ratio",
            "description": "Revenue concentration from top 5 customers"
        }
    },

    # =========================================================================
    # SERVICES (Professional Services)
    # Source: Services industry benchmarks
    # =========================================================================
    "services": {
        "churn_rate": {
            "p25": 0.02, "p50": 0.04, "p75": 0.07,
            "default": 0.04, "unit": "%/month",
            "description": "Monthly customer churn rate"
        },
        "revenue_growth_mom": {
            "p25": 0.02, "p50": 0.05, "p75": 0.09,
            "default": 0.05, "unit": "%/month",
            "description": "Month-over-month revenue growth"
        },
        "gross_margin": {
            "p25": 0.35, "p50": 0.50, "p75": 0.65,
            "default": 0.50, "unit": "ratio",
            "description": "Gross margin as percentage of revenue"
        },
        "burn_multiple": {
            "p25": 0.5, "p50": 0.9, "p75": 1.5,
            "default": 0.9, "unit": "ratio",
            "description": "Net burn divided by net new ARR"
        },
        "runway_months": {
            "p25": 12, "p50": 18, "p75": 30,
            "default": 18, "unit": "months",
            "description": "Cash runway in months"
        },
        "ltv_cac_ratio": {
            "p25": 3.0, "p50": 5.0, "p75": 8.0,
            "default": 5.0, "unit": "ratio",
            "description": "Lifetime value to customer acquisition cost ratio"
        },
        "cac_payback_months": {
            "p25": 6, "p50": 10, "p75": 16,
            "default": 10, "unit": "months",
            "description": "Months to recover CAC"
        },
        "net_revenue_retention": {
            "p25": 1.05, "p50": 1.12, "p75": 1.20,
            "default": 1.12, "unit": "ratio",
            "description": "Net revenue retention rate"
        },
        "logo_retention_12m": {
            "p25": 0.88, "p50": 0.92, "p75": 0.96,
            "default": 0.92, "unit": "ratio",
            "description": "12-month logo retention rate"
        },
        "rule_of_40": {
            "p25": 0.20, "p50": 0.35, "p75": 0.55,
            "default": 0.35, "unit": "ratio",
            "description": "Growth rate + profit margin"
        },
        "concentration_top5": {
            "p25": 0.30, "p50": 0.45, "p75": 0.60,
            "default": 0.45, "unit": "ratio",
            "description": "Revenue concentration from top 5 customers"
        }
    }
}


# =============================================================================
# STAGE-SPECIFIC ADJUSTMENT FACTORS
# =============================================================================

STAGE_ADJUSTMENTS: Dict[str, Dict[str, float]] = {
    "seed": {
        "churn_rate_mult": 1.3,
        "growth_mult": 1.5,
        "burn_mult": 1.8,
        "runway_mult": 0.7,
        "ltv_cac_mult": 0.8,
        "payback_mult": 1.3
    },
    "series_a": {
        "churn_rate_mult": 1.1,
        "growth_mult": 1.2,
        "burn_mult": 1.3,
        "runway_mult": 0.85,
        "ltv_cac_mult": 0.9,
        "payback_mult": 1.1
    },
    "series_b": {
        "churn_rate_mult": 1.0,
        "growth_mult": 1.0,
        "burn_mult": 1.0,
        "runway_mult": 1.0,
        "ltv_cac_mult": 1.0,
        "payback_mult": 1.0
    },
    "series_c": {
        "churn_rate_mult": 0.9,
        "growth_mult": 0.85,
        "burn_mult": 0.8,
        "runway_mult": 1.1,
        "ltv_cac_mult": 1.1,
        "payback_mult": 0.9
    },
    "growth": {
        "churn_rate_mult": 0.8,
        "growth_mult": 0.7,
        "burn_mult": 0.6,
        "runway_mult": 1.2,
        "ltv_cac_mult": 1.2,
        "payback_mult": 0.8
    },
    "late_stage": {
        "churn_rate_mult": 0.7,
        "growth_mult": 0.5,
        "burn_mult": 0.4,
        "runway_mult": 1.3,
        "ltv_cac_mult": 1.3,
        "payback_mult": 0.7
    }
}


# =============================================================================
# CALIBRATOR CLASS
# =============================================================================

class Calibrator:
    """
    Simulation calibrator for startup financial modeling.
    
    Provides industry-specific benchmarks and calibration methods
    for realistic simulation parameters.
    """

    def __init__(self):
        """Initialize the calibrator with benchmark data."""
        self.benchmarks = INDUSTRY_BENCHMARKS
        self.stage_adjustments = STAGE_ADJUSTMENTS
        self.industries = list(Industry)
        self.stages = list(Stage)
        logger.info("Calibrator initialized with %d industries", len(self.industries))

    def get_benchmark(self, industry: str, metric: str) -> Dict[str, Any]:
        """
        Get benchmark data for a specific industry and metric.
        
        Args:
            industry: Industry type (saas, fintech, etc.)
            metric: Metric name (churn_rate, ltv_cac_ratio, etc.)
            
        Returns:
            Dictionary with p25, p50, p75, default values
            
        Raises:
            ValueError: If industry or metric not found
        """
        if industry not in self.benchmarks:
            raise ValueError(f"Unknown industry: {industry}. "
                           f"Available: {list(self.benchmarks.keys())}")
        
        if metric not in self.benchmarks[industry]:
            raise ValueError(f"Unknown metric: {metric} for industry {industry}. "
                           f"Available: {list(self.benchmarks[industry].keys())}")
        
        return self.benchmarks[industry][metric]

    def get_default_value(self, industry: str, metric: str) -> float:
        """
        Get default benchmark value for simulation initialization.
        
        Args:
            industry: Industry type
            metric: Metric name
            
        Returns:
            Default value for the metric
        """
        benchmark = self.get_benchmark(industry, metric)
        return benchmark["default"]

    def get_benchmark_by_percentile(self, industry: str, metric: str, 
                                     percentile: str = "p50") -> float:
        """
        Get benchmark value at a specific percentile.
        
        Args:
            industry: Industry type
            metric: Metric name
            percentile: Percentile to retrieve (p25, p50, p75)
            
        Returns:
            Benchmark value at specified percentile
        """
        benchmark = self.get_benchmark(industry, metric)
        if percentile not in ["p25", "p50", "p75"]:
            raise ValueError(f"Invalid percentile: {percentile}. Use p25, p50, or p75")
        return benchmark[percentile]

    def get_all_metrics_for_industry(self, industry: str) -> Dict[str, Dict[str, Any]]:
        """
        Get all benchmark metrics for a specific industry.
        
        Args:
            industry: Industry type
            
        Returns:
            Dictionary of all metrics for the industry
        """
        if industry not in self.benchmarks:
            raise ValueError(f"Unknown industry: {industry}")
        return self.benchmarks[industry]

    def get_stage_adjusted_benchmark(self, industry: str, metric: str, 
                                      stage: str) -> Dict[str, Any]:
        """
        Get benchmark adjusted for startup stage.
        
        Args:
            industry: Industry type
            metric: Metric name
            stage: Startup stage (seed, series_a, etc.)
            
        Returns:
            Stage-adjusted benchmark values
        """
        base_benchmark = self.get_benchmark(industry, metric)
        
        if stage not in self.stage_adjustments:
            return base_benchmark
        
        adjustments = self.stage_adjustments[stage]
        adjusted = base_benchmark.copy()
        
        # Apply stage-specific adjustments
        if metric == "churn_rate":
            adjusted["default"] = base_benchmark["default"] * adjustments["churn_rate_mult"]
        elif metric == "revenue_growth_mom":
            adjusted["default"] = base_benchmark["default"] * adjustments["growth_mult"]
        elif metric == "burn_multiple":
            adjusted["default"] = base_benchmark["default"] * adjustments["burn_mult"]
        elif metric == "runway_months":
            adjusted["default"] = base_benchmark["default"] * adjustments["runway_mult"]
        elif metric == "ltv_cac_ratio":
            adjusted["default"] = base_benchmark["default"] * adjustments["ltv_cac_mult"]
        elif metric == "cac_payback_months":
            adjusted["default"] = base_benchmark["default"] * adjustments["payback_mult"]
        
        return adjusted

    def calibrate_simulation_params(self, industry: str, stage: str = "series_b",
                                     performance_tier: str = "p50") -> Dict[str, float]:
        """
        Generate calibrated simulation parameters for a startup.
        
        Args:
            industry: Industry type
            stage: Startup stage
            performance_tier: Performance tier (p25, p50, p75)
            
        Returns:
            Dictionary of calibrated parameter values
        """
        params = {}
        metrics = self.get_all_metrics_for_industry(industry)
        
        for metric_name, benchmark in metrics.items():
            # Get base value from performance tier
            base_value = benchmark.get(performance_tier, benchmark["default"])
            
            # Apply stage adjustment
            adjusted = self.get_stage_adjusted_benchmark(industry, metric_name, stage)
            
            # Use adjusted default if available, otherwise use base
            params[metric_name] = adjusted.get("default", base_value)
        
        return params

    def validate_metric(self, industry: str, metric: str, value: float) -> Dict[str, Any]:
        """
        Validate a metric value against industry benchmarks.
        
        Args:
            industry: Industry type
            metric: Metric name
            value: Value to validate
            
        Returns:
            Validation result with status and comparison info
        """
        benchmark = self.get_benchmark(industry, metric)
        p25, p50, p75 = benchmark["p25"], benchmark["p50"], benchmark["p75"]
        
        if value < p25:
            status = "below_benchmark"
            percentile = "<p25"
        elif value < p50:
            status = "below_median"
            percentile = "p25-p50"
        elif value < p75:
            status = "above_median"
            percentile = "p50-p75"
        else:
            status = "top_quartile"
            percentile = ">p75"
        
        return {
            "status": status,
            "percentile": percentile,
            "value": value,
            "benchmark_p25": p25,
            "benchmark_p50": p50,
            "benchmark_p75": p75,
            "unit": benchmark["unit"],
            "description": benchmark["description"]
        }

    def validate_all_metrics(self, industry: str, 
                              metrics: Dict[str, float]) -> Dict[str, Dict[str, Any]]:
        """
        Validate multiple metrics against industry benchmarks.
        
        Args:
            industry: Industry type
            metrics: Dictionary of metric names and values
            
        Returns:
            Dictionary of validation results for each metric
        """
        results = {}
        for metric_name, value in metrics.items():
            try:
                results[metric_name] = self.validate_metric(industry, metric_name, value)
            except ValueError as e:
                results[metric_name] = {"error": str(e)}
        return results

    def compare_to_benchmarks(self, industry: str, metrics: Dict[str, float]) -> Dict[str, Any]:
        """
        Compare company metrics to industry benchmarks.
        
        Args:
            industry: Industry type
            metrics: Dictionary of company metric values
            
        Returns:
            Comparison analysis with strengths and weaknesses
        """
        validation_results = self.validate_all_metrics(industry, metrics)
        
        strengths = []
        weaknesses = []
        
        for metric_name, result in validation_results.items():
            if "error" in result:
                continue
            
            if result["status"] in ["above_median", "top_quartile"]:
                strengths.append({
                    "metric": metric_name,
                    "value": result["value"],
                    "percentile": result["percentile"]
                })
            elif result["status"] in ["below_benchmark", "below_median"]:
                weaknesses.append({
                    "metric": metric_name,
                    "value": result["value"],
                    "percentile": result["percentile"]
                })
        
        return {
            "industry": industry,
            "strengths": strengths,
            "weaknesses": weaknesses,
            "strength_count": len(strengths),
            "weakness_count": len(weaknesses),
            "overall_assessment": self._generate_assessment(strengths, weaknesses)
        }

    def _generate_assessment(self, strengths: List[Dict], 
                             weaknesses: List[Dict]) -> str:
        """Generate overall assessment based on strengths and weaknesses."""
        if len(strengths) > len(weaknesses) * 2:
            return "strong_performer"
        elif len(strengths) > len(weaknesses):
            return "above_average"
        elif len(weaknesses) > len(strengths) * 2:
            return "needs_improvement"
        elif len(weaknesses) > len(strengths):
            return "below_average"
        else:
            return "average"

    def get_industry_summary(self, industry: str) -> Dict[str, Any]:
        """
        Get a summary of all benchmarks for an industry.
        
        Args:
            industry: Industry type
            
        Returns:
            Summary dictionary with key metrics and ranges
        """
        metrics = self.get_all_metrics_for_industry(industry)
        
        summary = {
            "industry": industry,
            "metric_count": len(metrics),
            "key_metrics": {}
        }
        
        for metric_name, benchmark in metrics.items():
            summary["key_metrics"][metric_name] = {
                "range": f"{benchmark['p25']:.2f} - {benchmark['p75']:.2f}",
                "median": benchmark["p50"],
                "default": benchmark["default"],
                "unit": benchmark["unit"]
            }
        
        return summary

    def list_available_industries(self) -> List[str]:
        """Return list of available industries."""
        return list(self.benchmarks.keys())

    def list_available_metrics(self, industry: Optional[str] = None) -> List[str]:
        """
        Return list of available metrics.
        
        Args:
            industry: Optional industry to filter metrics
            
        Returns:
            List of metric names
        """
        if industry:
            return list(self.benchmarks.get(industry, {}).keys())
        
        # Return all unique metrics across industries
        all_metrics = set()
        for ind_metrics in self.benchmarks.values():
            all_metrics.update(ind_metrics.keys())
        return sorted(list(all_metrics))

    def get_metric_descriptions(self) -> Dict[str, str]:
        """Get descriptions for all metrics."""
        descriptions = {}
        for industry, metrics in self.benchmarks.items():
            for metric_name, benchmark in metrics.items():
                if metric_name not in descriptions:
                    descriptions[metric_name] = benchmark["description"]
        return descriptions


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def create_calibrator() -> Calibrator:
    """Factory function to create a new Calibrator instance."""
    return Calibrator()


def get_quick_benchmark(industry: str, metric: str) -> float:
    """
    Quick access to default benchmark value.
    
    Args:
        industry: Industry type
        metric: Metric name
        
    Returns:
        Default benchmark value
    """
    calibrator = create_calibrator()
    return calibrator.get_default_value(industry, metric)


def list_industries() -> List[str]:
    """List all available industries."""
    return list(INDUSTRY_BENCHMARKS.keys())


def list_metrics() -> List[str]:
    """List all available metrics."""
    calibrator = create_calibrator()
    return calibrator.list_available_metrics()


# =============================================================================
# MAIN EXECUTION (for testing)
# =============================================================================

if __name__ == "__main__":
    # Test the calibrator
    calibrator = create_calibrator()
    
    print("=" * 60)
    print("SIMULATION CALIBRATOR - INDUSTRY BENCHMARKS")
    print("=" * 60)
    
    print("\n📊 Available Industries:")
    for industry in calibrator.list_available_industries():
        print(f"  • {industry}")
    
    print("\n📈 Available Metrics:")
    for metric in calibrator.list_available_metrics():
        print(f"  • {metric}")
    
    print("\n" + "=" * 60)
    print("SAMPLE: SaaS Benchmarks")
    print("=" * 60)
    
    saas_metrics = calibrator.get_all_metrics_for_industry("saas")
    for metric, data in saas_metrics.items():
        print(f"\n{metric}:")
        print(f"  p25: {data['p25']}, p50: {data['p50']}, p75: {data['p75']}")
        print(f"  default: {data['default']} {data['unit']}")
    
    print("\n" + "=" * 60)
    print("STAGE-ADJUSTED BENCHMARKS (SaaS, Series A)")
    print("=" * 60)
    
    adjusted = calibrator.calibrate_simulation_params("saas", "series_a", "p50")
    for metric, value in adjusted.items():
        print(f"  {metric}: {value:.3f}")
    
    print("\n" + "=" * 60)
    print("VALIDATION EXAMPLE")
    print("=" * 60)
    
    test_metrics = {
        "churn_rate": 0.04,
        "ltv_cac_ratio": 4.2,
        "gross_margin": 0.82
    }
    
    results = calibrator.validate_all_metrics("saas", test_metrics)
    for metric, result in results.items():
        print(f"\n{metric}:")
        print(f"  Status: {result['status']}")
        print(f"  Percentile: {result['percentile']}")
